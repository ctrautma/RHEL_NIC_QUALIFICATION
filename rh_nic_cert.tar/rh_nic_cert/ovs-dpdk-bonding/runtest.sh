#!/bin/bash
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   runtest.sh of /kernel/networking/ovs-dpdk/ovs-dpdk-bonding
#   Author: Ting Li <tli@redhat.com>
#   Modifier: Hekai wang <hewang@redhat.com>
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2013 Red Hat, Inc.
#
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# variables
PACKAGE="kernel"
CASE_PATH=${CASE_PATH:-"/mnt/tests/kernel/networking/ovs-dpdk/ovs-dpdk-bonding"}

if [[ $CUSTOMER_PFT == "true" ]]; then
    yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm;
    yum -y install beakerlib
    source /usr/share/beakerlib/beakerlib.sh
    yum -y install lrzip
    yum -y install tcpdump
else
    . /mnt/tests/kernel/networking/common/include.sh || exit 1
    . /mnt/tests/kernel/networking/common/lib/lib_nc_sync.sh || exit 1
    . /mnt/tests/kernel/networking/common/lib/lib_netperf_all.sh || exit 1
    . ${CASE_PATH}/env.sh || exit 1
fi

get_pmd_masks()
{
    local cpus=$1
    temp_list_array=`echo $cpus | tr -s ',' ' '`
    temp_array=($temp_list_array)
    temp_len=${#temp_array[@]}
    last_cpu_1=`echo ${temp_array[$temp_len-1]}`
    last_cpu_2=${temp_array[$temp_len-2]}
    sibling_cpu_1=`cat /sys/devices/system/cpu/cpu$last_cpu_1/topology/thread_siblings_list | awk -F ',' '{print $1}'`
    sibling_cpu_2=`cat /sys/devices/system/cpu/cpu$last_cpu_2/topology/thread_siblings_list | awk -F ',' '{print $1}'`
    pmd_mask=`printf "%x" $(( 0x1 << $last_cpu_1 | 0x1 << $last_cpu_2 | 0x1 << $sibling_cpu_1 | 0x1 << $sibling_cpu_2))`
    printf "%s" $pmd_mask
}

get_isolate_cpus()
{
    local nic_name=$1
    ISOLCPUS_SERVER=$(cat /sys/class/net/${nic_name}/device/local_cpulist)
    case ${ISOLCPUS_SERVER} in
        0,* )
            ISOLCPUS_SERVER=`echo $ISOLCPUS_SERVER | cut -c 3-`
            ;;
        0-* | [1-9]-* )
            last=""
            temp_str=`echo $ISOLCPUS_SERVER | sed 's/-/../g' | tr -s ',' ' '`
            for item in $temp_str
            do
                ex_item="{$item}"
                real_item=`eval "echo $ex_item"`
                last=$last$real_item" "
            done
            last=`echo $last | tr -s ' ' ','`
            if [[ `echo $last | awk /'^0,'/ ` ]];then
                ISOLCPUS_SERVER=`echo $last | cut -c 3-`
            else
                ISOLCPUS_SERVER=${last}
            fi
            ;;
        * )
            true
            ;;
    esac
    printf "%s" $ISOLCPUS_SERVER
}


add_yum_profiles()
{

    local latest_qemu_rpm='http://download.lab.bos.redhat.com/rcm-guest/puddles/OpenStack/rhos-release/rhos-release-latest.noarch.rpm'
    yum install -y ${latest_qemu_rpm}
    test -f /etc/yum.repos.d/rhos-release-14.repo || install /var/lib/rhos-release/repos/rhos-release-14.repo /etc/yum.repos.d/

#	cat <<-EOT >> /etc/yum.repos.d/osp8-rhel.repo
#		[osp8-rhel7]
#		name=osp8-rhel7
#		baseurl=http://download.lab.bos.redhat.com/rcm-guest/puddles/OpenStack/14.0-RHEL-7/latest/RH7-RHOS-14.0/x86_64/os/
#		enabled=1
#		gpgcheck=0
#		skip_if_unavailable=1
#	EOT

	cat <<-EOT >> /etc/yum.repos.d/tuned.repo
		[tuned]
		name=Tuned development repository for RHEL-7
		baseurl=https://fedorapeople.org/~jskarvad/tuned/devel/repo/
		enabled=1
		gpgcheck=0
	EOT

	yum install yum-utils -y
	rpm --import "http://keyserver.ubuntu.com/pks/lookup?op=get&search=0x3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF"

	cat <<-EOT >> /etc/yum.repos.d/tuned.repo
		[tuned]
		name=mono-repo
		baseurl=http://download.mono-project.com/repo/centos/
		enabled=1
		gpgcheck=0
		skip_if_unavailable=1
	EOT
}

install_mono_rpm() 
{
        echo "start to install mono rpm..."
        yum install yum-utils -y
        #rpm --import "http://keyserver.ubuntu.com/pks/lookup?op=get&search=0x3FA7E0328081BFF6A14DA29AA6A19B38D3D831EF"
        #yum-config-manager --add-repo http://download.mono-project.com/repo/centos/
        yum -y install mono-complete-5.8.0.127-0.xamarin.3.epel7.x86_64
        #yum -y install mono-complete-5.8.0.127-0.xamarin.3.epel7.x86_64
        #yum-config-manager --disable download.mono-project.com_repo_centos_
}


download_Xena2544() 
{
        echo "start to download xena2544.exe to xena folder..."
        wget -P /root/ http://netqe-infra01.knqe.lab.eng.bos.redhat.com/Xena2544.exe > /dev/null 2>&1
        if [ `hostname| grep -P netqe[0-9]+.knqe.lab.eng.bos.redhat.com` ];then		
                wget -P /root/ http://netqe-infra01.knqe.lab.eng.bos.redhat.com/tli_bond.x2544 > /dev/null 2>&1
        else
        	if [[ $TRAFFIC_PORT_ONE = *"M9"* ]]; then
        		#statements
        		wget -P /root/ http://netqe-bj.usersys.redhat.com/share/wanghekai/config/bond_test/hewang_ovs_dpdk_bonding-bj-M9.x2544
        	else
        		wget -P /root/ http://netqe-bj.usersys.redhat.com/share/wanghekai/config/bond_test/hewang_ovs_dpdk_bonding-bj-M5.x2544
        	fi

        fi
}

install_rpms()
{
        #add repo
        /bin/bash ./repo.sh
        if rpm -qa | grep yum-utils;then
                true
        else
                yum install -y yum-utils
        fi
        if rpm -qa | grep python36u;then
                true
        else
                yum -y install python36 python36-devel python36-pip python36-tkinter
        fi
        if rpm -qa | grep scl-utils;then
                true
        else
                yum -y install scl-utils
        fi
        if rpm -qa | grep wget;then
                true
        else
                yum install -y wget nano ftp yum-utils git tuna openssl sysstat
        fi
        if rpm -qa | grep tuned-profiles-cpu-partitioning;then
                true
        else
                yum -y install tuned-profiles-cpu-partitioning
        fi

        #install qemu packages
        yum install -y qemu-img-rhev qemu-kvm-common-rhev qemu-kvm-rhev qemu-kvm-tools-rhev
        #install libvirt
        yum install -y libvirt virt-install virt-manager virt-viewer
        #for qemu bug that can not start qemu 
        echo -e "group = 'hugetlbfs'" >> /etc/libvirt/qemu.conf
        systemctl restart libvirtd
        #install python
        yum install -y python
        #install zmq for trex 
        yum install -y czmq-devel

        rpm -qa | grep python.*pip || init_python_env

}

init_python_env()
{
        python3.6 -m venv ${CASE_PATH}/venv
        source venv/bin/activate
        if ! pip list --format=legacy | grep fire;then
                pip install fire
        fi
        if ! pip list --format=legacy | grep psutil;then
                pip install psutil
        fi
        if ! pip list --format=legacy | grep paramiko;then
                pip install paramiko
        fi
        pip install xmlrunner
}


install_ovs()
{
        local ovs_version=${OVS_URL##*/}
        ovs_version=${ovs_version%.rpm}
        if rpm -qa | grep $ovs_version;then
                true
        else
            yum install -y ${OVS_SELINUX_URL}
            #rpm -ivh %{OVS_SELINUX_URL}
            rpm -ivh ${OVS_URL}
        fi
}

install_driverctl()
{
    DRIVERCTL_URL=http://download-node-02.eng.bos.redhat.com/brewroot/packages/driverctl/0.95/1.el7fdparch/noarch/driverctl-0.95-1.el7fdparch.noarch.rpm
	yum install -y ${DRIVERCTL_URL}
}

install_dpdk()
{
    rpm -ivh ${DPDK_URL}
    rpm -ivh ${DPDK_TOOL_URL}
}

init_netscout_tool()
{
	netscout_url=https://github.com/ctrautma/NetScout.git
    scout_dir=`echo ${netscout_url##*/} | awk -F . '{print $1}'`
    if [ ! -d ${CASE_PATH}/$scout_dir ];then
    	git clone $netscout_url
    fi
    pushd $scout_dir
    chmod 777 NSConnect.py
    popd
}

scout_connect()
{
    local port1=$1
    local port2=$2
    pushd $scout_dir
    echo "NETSCOUT CONNECT PORT $port1 AND $port2"
    rlRun "python36 NSConnect.py --connect $port1 $port2"
    popd
}
scout_disconnect()
{
    local port1=$1
    local port2=$2
    pushd $scout_dir
    echo "NETSCOUT DISCONNECT PORT $port1 AND $port2"
    rlRun "python36 NSConnect.py --disconnect $port1 $port2"
    popd
}

scout_show()
{
    pushd $scout_dir
    rlRun "python36 NSConnect.py --showconnections"
    popd
}

init_netscout_config()
{
    pushd $scout_dir
    if [ `hostname | grep -P netqe[0-9]+.knqe.lab.eng.bos.redhat.com` ];then
		cat > $CASE_PATH/$scout_dir/settings.cfg <<-EOF
		[INFO]
		password = bmV0c2NvdXQx
		username = YWRtaW5pc3RyYXRvcg==
		port = NTMwNTg=
		host = MTAuMTkuMTUuNjU=
		EOF
    else
		if [[ "$NETSCOUT_HOST" != "" ]]; then
		host_name=`echo -n $NETSCOUT_HOST | base64`
		cat > $CASE_PATH/$scout_dir/settings.cfg <<-EOF
		[INFO]
		password = bmV0c2NvdXQx
		username = YWRtaW5pc3RyYXRvcg==
		port = NTMwNTg=
		host = $host_name
		EOF

		fi
    fi
    popd
}



init_physical_topo()
{
    init_netscout_tool
    init_netscout_config

    case $CONN_TYPE in
        "netscout" )
            case $TRAFFIC_TYPE in
                "xena" | "trex" )
					if [[ $BOND_TYPE == "bond_active_balance_tcp_switch" ]]; then
						scout_connect $TRAFFIC_PORT_ONE $SERVER_TRAFFIC_PORT_ONE
						scout_connect $TRAFFIC_PORT_TWO $SERVER_TRAFFIC_PORT_TWO
						scout_connect $SERVER_PORT_ONE $SWITCH_TRAFFIC_PORT_1
						scout_connect $SERVER_PORT_TWO $SWITCH_TRAFFIC_PORT_2
						scout_connect $CLIENT_PORT_ONE $SWITCH_TRAFFIC_PORT_3
						scout_connect $CLIENT_PORT_TWO $SWITCH_TRAFFIC_PORT_4
					else
						scout_connect $TRAFFIC_PORT_ONE $SERVER_TRAFFIC_PORT_ONE
						scout_connect $TRAFFIC_PORT_TWO $SERVER_TRAFFIC_PORT_TWO
						scout_connect $SERVER_PORT_ONE $CLIENT_PORT_ONE
						scout_connect $SERVER_PORT_TWO $CLIENT_PORT_TWO
					fi
                    ;;
                * )
					echo "unsupport TRAFFIC_TYPE"
					;;
            esac
            ;;
        "switch" )
			echo "Here the machine is connect to switch DO NOTHING"	
            ;;
        "direct" )
			echo "Here the machine is connect directly DO NOTHING"
            ;;
        * )
			echo "current not support CONN_TYPE"
            ;;
    esac
}



config_hugepage() 
{
	#config the hugepage
	. /etc/os-release

	if [ $VERSION_ID == "7.4" ] || [ $VERSION_ID == "7.3" ];then
		rpm -Uvh http://download-node-02.eng.bos.redhat.com/brewroot/packages/tuned/2.8.0/3.el7/noarch/tuned-2.8.0-3.el7.noarch.rpm --nodeps
		rpm -ivh http://download-node-02.eng.bos.redhat.com/brewroot/packages/tuned/2.8.0/3.el7/noarch/tuned-profiles-realtime-2.8.0-3.el7.noarch.rpm --nodeps
		rpm -ivh http://download-node-02.eng.bos.redhat.com/brewroot/packages/tuned/2.8.0/3.el7/noarch/tuned-profiles-nfv-2.8.0-3.el7.noarch.rpm --nodeps
		rpm -ivh http://download-node-02.eng.bos.redhat.com/brewroot/packages/tuned/2.8.0/3.el7/noarch/tuned-profiles-cpu-partitioning-2.8.0-3.el7.noarch.rpm --nodeps

	else
	        yum install -y tuned-profiles-cpu-partitioning
	fi

	if i_am_server; then
	        echo -e "isolated_cores=$ISOLCPUS_SERVER" >> /etc/tuned/cpu-partitioning-variables.conf
	        tuned-adm profile cpu-partitioning
	        sed -i '/GRUB_CMDLINE_LINUX_DEFAULT=/c\GRUB_CMDLINE_LINUX_DEFAULT="isolcpus='"$ISOLCPUS_SERVER"' ${GRUB_CMDLINE_LINUX_DEFAULT:+$GRUB_CMDLINE_LINUX_DEFAULT }\\$tuned_params"' /etc/default/grub
	fi
	if i_am_client; then
	        echo -e "isolated_cores=$ISOLCPUS_CLIENT" >> /etc/tuned/cpu-partitioning-variables.conf
	        tuned-adm profile cpu-partitioning
	        sed -i '/GRUB_CMDLINE_LINUX_DEFAULT=/c\GRUB_CMDLINE_LINUX_DEFAULT="isolcpus='"$ISOLCPUS_CLIENT"' ${GRUB_CMDLINE_LINUX_DEFAULT:+$GRUB_CMDLINE_LINUX_DEFAULT }\\$tuned_params"' /etc/default/grub
	fi
	sed -i 's/\(GRUB_CMDLINE_LINUX.*\)"$/\1/g' /etc/default/grub
	if [ $NIC_DRIVER == "qede" ];then
	    sed -i "s/GRUB_CMDLINE_LINUX.*/& nohz=on default_hugepagesz=1G hugepagesz=1G hugepages=24 intel_iommu=on iommu=pt modprobe.blacklist=qedi modprobe.blacklist=qedf modprobe.blacklist=qedr \"/g" /etc/default/grub
	else
	    sed -i "s/GRUB_CMDLINE_LINUX.*/& nohz=on default_hugepagesz=1G hugepagesz=1G hugepages=24 intel_iommu=on iommu=pt\"/g" /etc/default/grub
	fi
	grub2-mkconfig -o /boot/grub2/grub.cfg
	rhts-reboot
	cat /proc/cmdline
}



enable_dpdk() 
{
        install_dpdk
        install_driverctl

        nic1_businfo=$(ethtool -i $1 | grep "bus-info" | awk  '{print $2}')
        nic2_businfo=$(ethtool -i $2 | grep "bus-info" | awk  '{print $2}')
        nic1_mac=$(ethtool -P $1 | awk '{print $NF}')
        nic2_mac=$(ethtool -P $2 | awk '{print $NF}')
        modprobe vfio-pci
        modprobe vfio
        local driver_name=`ethtool -i $1 | grep driver | awk '{print $NF}'`
        if [ "$driver_name" == "mlx5_core" ];then
            return 0
        fi


        if [[ -f /usr/share/dpdk/usertools/dpdk-devbind.py ]]; then
        	#statements
        	echo "using dpdk-devbind.py set the vfio-pci driver to nic"
        	/usr/share/dpdk/usertools/dpdk-devbind.py -b vfio-pci ${nic1_businfo}
	        /usr/share/dpdk/usertools/dpdk-devbind.py -b vfio-pci ${nic2_businfo}
	        /usr/share/dpdk/usertools/dpdk-devbind.py --status
	    else
	    	echo "using driverctl set the vfio-pci driver to nic"
	    	driverctl -v set-override $nic1_businfo vfio-pci
	        sleep 3
	        driverctl -v set-override $nic2_businfo vfio-pci
	        sleep 3
	        driverctl -v list-devices|grep vfio-pci
        fi
}


bonding_nic() 
{
    if [[ "$NIC_DRIVER" == "nfp" ]];then
        #here need update /etc/sysconfig/openvswitch
        sed -ie 's/OVS_USER_ID/#OVS_USER_ID/g' /etc/sysconfig/openvswitch 

    fi

	modprobe openvswitch
	systemctl stop openvswitch
	sleep 3
	systemctl start openvswitch
	sleep 3

	ovs-vsctl --if-exists del-br ovsbr0
	sleep 5

	ovs-vsctl set Open_vSwitch . other_config={}
	ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-init=true
	ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-socket-mem="4096,4096"
	ovs-vsctl set Open_vSwitch . other_config:pmd-cpu-mask=$1
    ovs-vsctl --no-wait set Open_vSwitch . other_config:vhost-iommu-support=true
	systemctl restart openvswitch
	sleep 3
	ovs-vsctl add-br ovsbr0 -- set bridge ovsbr0 datapath_type=netdev
    
    # if i_am_server;then
    #     local nic1_mac=$(ethtool -P ${SERVER_NIC1_NAME} | awk '{print $NF}')
    #     local nic2_mac=$(ethtool -P ${SERVER_NIC2_NAME} | awk '{print $NF}')
    # elif i_am_client; then
    #     local nic1_mac=$(ethtool -P ${CLIENT_NIC1_NAME} | awk '{print $NF}')
    #     local nic2_mac=$(ethtool -P ${CLIENT_NIC2_NAME} | awk '{print $NF}')
    # else
    #     echo "host Invalid role,neither server nor client !"
    # fi

    if [[ "$nic1_businfo" == "$nic2_businfo" ]]; then
        ovs-vsctl add-bond ovsbr0 dpdkbond dpdk0 dpdk1 "bond_mode=$2" \
        -- set Interface dpdk0 type=dpdk options:dpdk-devargs=class=eth,mac=${nic1_mac} mtu_request=9000 \
        -- set Interface dpdk1 type=dpdk options:dpdk-devargs=class=eth,mac=${nic2_mac} mtu_request=9000
    else
        ovs-vsctl add-bond ovsbr0 dpdkbond dpdk0 dpdk1 "bond_mode=$2" \
        -- set Interface dpdk0 type=dpdk options:dpdk-devargs=${nic1_businfo} mtu_request=9000 \
        -- set Interface dpdk1 type=dpdk options:dpdk-devargs=${nic2_businfo} mtu_request=9000
    fi
	
	#ovs-vsctl add-port ovsbr0 vhost0 -- set interface vhost0 type=dpdkvhostuser

    ovs-vsctl add-port ovsbr0 vhost0 -- set interface vhost0 type=dpdkvhostuserclient options:vhost-server-path=/tmp/vhost0

	#ovs-vsctl set Open_vSwitch . other_config:pmd-cpu-mask=$1

	#chmod 777 /var/run/openvswitch/vhost0

	ovs-ofctl del-flows ovsbr0

	ovs-ofctl add-flow ovsbr0 actions=NORMAL

	sleep 2
	ovs-vsctl show
	sleep 5
	echo "after bonding nic, check the bond status"
	ovs-appctl bond/show
    if [ "$2" == "${BOND_MODE_ACTIVE_BACKUP}" ];then
        ovs-appctl bond/set-active-slave dpdkbond dpdk0
        ovs-vsctl add-port ovsbr0 whk -- set interface whk type=internal
        ip li set whk up
    fi
    sleep 30
    ovs-appctl bond/show
}


cpu_list_on_numa()
{
        local numa_node=${1:-0}
        local cpulist=""
        local i=""
        local CPU=""

        CPU=$(lscpu | grep "NUMA node${numa_node} CPU(s):" | awk '{print $NF}')
        CPU=$(echo -n $CPU | sed 's/,/ /g' | sed s/-/../g)

        for i in $CPU
        do
                echo $i | grep '\.\.' > /dev/null && \
                cpus=$(
                        bash -c "
                                list=''
                                for i in {$i}
                                do
                                        [ -z \"\$list\" ] && list="\$i" || list+=\" \$i\"
                                done
                                echo \$list
                ") || cpus="$i "
                [ -z "$cpulist" ] && cpulist=$cpus || cpulist+=" $cpus"
        done
        echo -n $cpulist
}


vcpupin_in_xml()
{
    local numa_node=$1
    local number_of_required_cpu_cores=$2
    local template_xml=$3
    local new_xml=$4

    local cpu_list=($(cpu_list_on_numa $numa_node))

    pushd $CASE_PATH 1>/dev/null
    cp $template_xml $new_xml

    python vm_xml_op.py update_vcpu $new_xml 0  ${cpu_list[0]}

        function vcpupin()
        {
                local vcpu=$1
                local cpuset=$2

                grep -e "<vcpupin vcpu='$vcpu' cpuset='$vcpu'\/>" $new_xml >/dev/null && \
                sed -i -e "s/[[:space:]]*<vcpupin vcpu='$vcpu' cpuset='$vcpu'\/>/    <vcpupin vcpu='$vcpu' cpuset='$cpuset'\/>/" $new_xml || \
                sed -i $new_xml -f - <<- SED_SCRIPT
                        #n
                        H
                        $ {
                                g
                                s/^/    <vcpupin vcpu='$vcpu' cpuset='$cpuset'\/>/
                                p
                                b
                        }
                        /<vcpupin vcpu=/ {
                                g
                                s/^\n//
                                p
                                s/.*//
                                h
                                b
                        }
		SED_SCRIPT
        }

        #vcpupin 0 ${cpu_list[0]}
        for ((i=1; i<=number_of_required_cpu_cores; i++))
        do
                if ((i % 2))
                then
                    python vm_xml_op.py update_vcpu $new_xml $i  ${cpu_list[((i/2+1))]}
                    #vcpupin $i ${cpu_list[((i/2+1))]}
                else
                    local_temp_cpu=$(cat /sys/devices/system/cpu/cpu${cpu_list[((i/2))]}/topology/thread_siblings_list | awk -F ',' '{print $NF}')
                    python vm_xml_op.py update_vcpu $new_xml $i $local_temp_cpu
                    #vcpupin $i $(cat /sys/devices/system/cpu/cpu${cpu_list[((i/2))]}/topology/thread_siblings_list | awk -F ',' '{print $NF}')
                fi
        done
        #sed -i -e "s/[[:space:]]*<emulatorpin cpuset='1'\/>/    <emulatorpin cpuset='${cpu_list[0]}'\/>/" $new_xml
        #grep -e "memory mode" $new_xml >/dev/null && \
        python vm_xml_op.py update_numa $new_xml $numa_node
        #if [ $numa_node == 1 ];then
        #        sed -i -e "s/nodeset='0'/nodeset='1'/" $new_xml
        #fi
        if [ $5 == 'server' ];then
            python vm_xml_op.py update_vhostuser_interface $new_xml "52:54:00:11:8f:ea" "0x00"
            #sed -i "s/52:54:00:11:8f:ea/52:54:00:11:8f:ea/" g1.xml &>/dev/null
            #sed -i "s/slot='0x00'/slot='0x08'/" g1.xml &>/dev/null
        elif [ $5 == 'client' ];then
            python vm_xml_op.py update_vhostuser_interface $new_xml "52:54:00:11:8f:e8" "0x00"
            #sed -i "s/52:54:00:11:8f:ea/52:54:00:11:8f:e8/" g1.xml &>/dev/null
            #sed -i "s/slot='0x08'/slot='0x09'/" g1.xml &>/dev/null
        fi
	popd 1>/dev/null
}


start_guest()
{
    if [[ $CUSTOMER_PFT == "true" ]]; then
        [[ -f /root/$(basename $IMG_GUEST) ]] || wget -P /root/  $IMG_GUEST > /dev/null 2>&1
        pushd /root 1>/dev/null
        [[ -f /root/rhel7.5-vsperf.qcow2 ]] || lrzip -d "$(basename $IMG_GUEST)"
        [[ -f /root/rhel7.5-vsperf.qcow2 ]] || mv $(basename -s .lrz $IMG_GUEST) rhel7.5-vsperf.qcow2
        popd 1>/dev/null
        virsh define ${CASE_PATH}/g1.xml
        chmod 777 /root/
        virsh start guest30032
    else
        if [ `hostname | grep netqe` ];then
            #for US test
            WEB_SERVER=http://netqe-infra01.knqe.lab.eng.bos.redhat.com/vm/rhel7.5-vsperf-1Q.qcow2
            wget -P /root/  $WEB_SERVER > /dev/null 2>&1
            mv /root/rhel7.5-vsperf-1Q.qcow2 /root/rhel7.5-vsperf.qcow2
        else
            local image_name="rhel7.5-vsperf.qcow2"
            if [[ "$GUEST_IMG" == "7.6" ]]; then
                image_name="rhel7.6-vsperf-1Q-viommu.qcow2"
            elif [[ "$GUEST_IMG" == "7.5" ]]; then
                image_name="rhel7.5-vsperf.qcow2"
            else
                echo "Current Not support this version"
            fi
            wget -P /root/ ${WEB_SERVER}/$image_name > /dev/null 2>&1

        fi
        #echo -e "group = 'hugetlbfs'" >> /etc/libvirt/qemu.conf
        virsh define ${CASE_PATH}/g1.xml
        chmod 777 /root/
        virsh start guest30032
    fi
}

destroy_guest()
{
    virsh destroy guest30032
    virsh undefine guest30032
}


configure_guest()
{
	local cmd=(
            {iptables -t filter -P INPUT ACCEPT}
			{iptables -t filter -P FORWARD ACCEPT}
			{iptables -t filter -P OUTPUT ACCEPT}
			{iptables -t mangle -P PREROUTING ACCEPT}
			{iptables -t mangle -P INPUT ACCEPT}
			{iptables -t mangle -P FORWARD ACCEPT}
			{iptables -t mangle -P OUTPUT ACCEPT}
			{iptables -t mangle -P POSTROUTING ACCEPT}
			{iptables -t nat -P PREROUTING ACCEPT}
			{iptables -t nat -P INPUT ACCEPT}
			{iptables -t nat -P OUTPUT ACCEPT}
			{iptables -t nat -P POSTROUTING ACCEPT}
			{iptables -t filter -F}
			{iptables -t filter -X}
			{iptables -t mangle -F}
			{iptables -t mangle -X}
			{iptables -t nat -F}
			{iptables -t nat -X}
			{ip6tables -t filter -P INPUT ACCEPT}
			{ip6tables -t filter -P FORWARD ACCEPT}
			{ip6tables -t filter -P OUTPUT ACCEPT}
			{ip6tables -t mangle -P PREROUTING ACCEPT}
			{ip6tables -t mangle -P INPUT ACCEPT}
			{ip6tables -t mangle -P FORWARD ACCEPT}
			{ip6tables -t mangle -P OUTPUT ACCEPT}
			{ip6tables -t mangle -P POSTROUTING ACCEPT}
			{ip6tables -t nat -P PREROUTING ACCEPT}
			{ip6tables -t nat -P INPUT ACCEPT}
			{ip6tables -t nat -P OUTPUT ACCEPT}
			{ip6tables -t nat -P POSTROUTING ACCEPT}
			{ip6tables -t filter -F}
			{ip6tables -t filter -X}
			{ip6tables -t mangle -F}
			{ip6tables -t mangle -X}
			{ip6tables -t nat -F}
			{ip6tables -t nat -X}
			{ip addr add $1/24 dev eth1}
            {ip -d addr show}
                )

	vmsh cmd_set guest30032 "${cmd[*]}"
}


#{modprobe  vfio enable_unsafe_noiommu_mode=1}
guest_start_testpmd()
{
        local cmd=(
			{/root/one_gig_hugepages.sh 1}
            {rpm -ivh /root/dpdkrpms/$GUEST_DPDK_VERSION/dpdk*.rpm}
            {modprobe -r vfio_iommu_type1}
            {modprobe -r vfio}
            {modprobe  vfio }
            {modprobe vfio-pci}
            {dpdk-devbind -b vfio-pci 0000:00:09.0}
            {dpdk-devbind --status}
                )
        vmsh cmd_set guest30032 "${cmd[*]}"
        local q_num=${GUEST_TESTPMD_Q_NUM}
        VMSH_PROMPT1="testpmd>" VMSH_NORESULT=1 VMSH_NOLOGOUT=1 vmsh run_cmd guest30032 "testpmd -l 0,1,2 --socket-mem 1024 -n 4 -- --forward-mode=macswap --port-topology=chained --disable-hw-vlan --disable-rss -i --rxq=${q_num} --txq=${q_num} --rxd=256 --txd=256 --nb-cores=2 --auto-start"
}


down_dpdk0() 
{
    init_netscout_tool
    init_netscout_config
	case $CONN_TYPE in
        "netscout" )
            case $TRAFFIC_TYPE in
                "xena" | "trex" )
					if [[ $BOND_TYPE == "bond_active_balance_tcp_switch" ]]; then
                        if i_am_server;then
    						scout_disconnect $SERVER_PORT_ONE $SWITCH_TRAFFIC_PORT_1
                        elif i_am_client; then
						  scout_disconnect $CLIENT_PORT_ONE $SWITCH_TRAFFIC_PORT_3
                        else
                            echo "Invalid Host role , Please check it "
                        fi

                        active_port=`ovs-appctl bond/show|grep 'active slave mac'|awk -F ' ' '{print $4}' |awk -F '(' '{print $2}' |awk -F ')' '{print $1}'`
                        if [[ $active_port == "dpdk0" ]]; then

                            echo "HERE we find that we down the error port "
                            echo "We connect it again and disconnect another port"
                            if i_am_server;then
                                scout_connect $SERVER_PORT_ONE $SWITCH_TRAFFIC_PORT_1
                                scout_disconnect $SERVER_PORT_TWO $SWITCH_TRAFFIC_PORT_2
                            elif i_am_client; then
                                scout_connect $CLIENT_PORT_ONE $SWITCH_TRAFFIC_PORT_3
                                scout_disconnect $CLIENT_PORT_TWO $SWITCH_TRAFFIC_PORT_4
                            else
                                echo "Invalid Host role , Please check it "
                            fi
                        fi

					else
						scout_disconnect $SERVER_PORT_ONE $CLIENT_PORT_ONE
                        active_port=`ovs-appctl bond/show|grep 'active slave mac'|awk -F ' ' '{print $4}' |awk -F '(' '{print $2}' |awk -F ')' '{print $1}'`
                        if [[ $active_port == "dpdk0" ]]; then
                            #this means we down the error config port
                            echo "HERE we find that we down the error port "
                            echo "We connect it again and disconnect another port"
                            scout_connect $SERVER_PORT_ONE $CLIENT_PORT_ONE
                            scout_disconnect $SERVER_PORT_TWO $CLIENT_PORT_TWO
                        fi
					fi
                    ;;
                * )
					echo "unsupport TRAFFIC_TYPE"
					;;
            esac
            ;;
        "switch" )
            rlRun -l "active_port=`ovs-appctl bond/show|grep 'active slave mac'|awk -F ' ' '{print $4}' |awk -F '(' '{print $2}' |awk -F ')' '{print $1}'`"
            rlRun -l "swcfg port_down $swname ${PORT_MAP["$active_port"]}"
			echo "Here the machine is connect to switch"	
            ;;
        "direct" )
			echo "Here the machine is connect directly DO NOTHING"
            ;;
        * )
			echo "current not support CONN_TYPE"
            ;;
    esac

    return 0

}

#only use this func on server side 
bonding_active_backup_failover_and_latency()
{
        file_name=latencylog
        rm -f $file_name
        packet_all=60000
        packet_loss=$(vmsh run_cmd guest30032 "timeout -s SIGINT 80 ping -n -i 0.001 ${CLIENT_GUEST_IP} -c $packet_all " > ${CASE_PATH}/$file_name &)
        echo "begin down_dpdk0 "`date`
        down_dpdk0
        echo "end down_dpdk0"`date`
        sleep 80
        echo "after down dpdk0 port, check bond status"
        ovs-appctl bond/show
        echo "current path "$(pwd)
        loss_packet=$(( $packet_all - `grep received ${CASE_PATH}/$file_name  | awk -F ',' '{print $2}' | awk '{print $1}' ` ))
        loss_packet_time=$(( $loss_packet * 1 ))
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"
        echo "loss packet time is "$loss_packet_time" ms"
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"
        echo "***************************************************************************************************"

        real_packet_loss=`grep max ${CASE_PATH}/$file_name | awk -F '=' '{print $2}' | awk -F '/' '{print $3}'`
        if [ "$real_packet_loss" != "" ];then
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
            echo "test result latency "$real_packet_loss" ms"
        else
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
        echo "********************************************************************************"
         	echo "test result latency unknown ms"
        fi
        if [ -f $file_name ];then
                rlFileSubmit $file_name
        fi
        return 0
}


#only enable on netscout conn
check_active_backup_conn()
{
    if i_am_server;then
        ip li set whk up 
        ip ad ad 192.168.30.100/24 dev whk
        sync_wait client IP_CONN_READY
        #here ping client and adjust conn
        echo "*************************************************************************"
        echo "*************************************************************************"
        ovs-appctl bond/show
        #SERVER_PORT_ONE=01.01.43
        #SERVER_PORT_TWO=01.01.44
        #current_active_slave=`ovs-appctl bond/show | grep 'active slave mac' | awk -F '(' '{print $NF}' | tr -d ')'`
        #set_slave=dpdk0
        #if [[ $current_active_slave == "dpdk0" ]]; then
        #    set_slave="dpdk1"
        #    #statements
        #else
        #    set_slave="dpdk0"
        #fi
        #ping -c 3 192.168.30.101 -W 5 || ovs-appctl bond/set-active-slave dpdkbond $set_slave
        port_config_fix=0
        ping -c 3 192.168.30.101 -W 5 || port_config_fix=100
        if [[ $port_config_fix == 100 ]]; then
            echo "Current netscout port config need fix !!!!!!!!!!!!"
            echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
            echo "swap the port config"
            temp_port=${SERVER_PORT_ONE}
            SERVER_PORT_ONE=${SERVER_PORT_TWO}
            SERVER_PORT_TWO=${temp_port}
            init_physical_topo
        fi
        ovs-appctl bond/set-active-slave dpdkbond dpdk0
        ovs-appctl bond/show
        echo "*************************************************************************"
        echo "*************************************************************************"
        sync_set client UPDATE_DPDK_BOND_PORT_SET
    elif i_am_client; then
        ip li set whk up
        ip ad ad 192.168.30.101/24 dev whk
        sync_set server IP_CONN_READY
        sync_wait server UPDATE_DPDK_BOND_PORT_SET
        ovs-appctl bond/set-active-slave dpdkbond dpdk0
    else
        echo "host role error"
    fi
}

########################################################################
bonding_test_active_backup()
{
        rlRun -l "check_active_backup_conn"
        if i_am_server; then 
            sync_wait client CLIENT_READY
            rlRun "vmsh run_cmd guest30032 \"iperf -c ${CLIENT_GUEST_IP} -p 8080\""
            rlRun "vmsh run_cmd guest30032 \"ping -n -i 0.001 ${CLIENT_GUEST_IP} -c 10000\""
            rlRun "bonding_active_backup_failover_and_latency"
            sync_set client SERVER_REARY
        elif i_am_client;then
            rlRun "vmsh run_cmd guest30032 \"iperf -s -p 8080 &\""
            sync_set server CLIENT_READY
            sync_wait server SERVER_REARY
            echo "after down dpdk0 port, check bond status"
            ovs-appctl bond/show	
        else
            test_fail "not client or server, test fail"
        fi
}

bonding_test_balance_slb()
{
        if i_am_server; then
            rlRun "vmsh run_cmd guest30032 \"iperf -s -p 8080 &\""
            sync_set client SERVER_REARY
            sync_wait client PERFORMANCE_READY
            if [ "$THROUGH_PUT_TRAFFIC_TYPE" == "trex" ];then
                rlRun "bonding_test_trex"
            else
                install_mono_rpm
                download_Xena2544
                bonding_test_xena
            fi
        elif i_am_client;then
            sync_wait server SERVER_REARY
            rlRun "vmsh run_cmd guest30032 \"iperf -c ${SERVER_GUEST_IP} -p 8080\""
            rlRun "vmsh run_cmd guest30032 \"ping -n -i 0.001 ${SERVER_GUEST_IP} -c 1000\""
            #begin prepare start testpmd
            rlRun "destroy_guest"
            rlRun "start_guest"
            rlRun "guest_start_testpmd"
            sync_set server PERFORMANCE_READY
        else
            test_fail "not client or server, test fail"
        fi
}


bonding_test_balance_tcp()
{
        if i_am_server; then
            rlRun "vmsh run_cmd guest30032 \"iperf -s -p 8080 &\" "
    		sync_set client SERVER_REARY
        elif i_am_client;then
        	sync_wait server SERVER_REARY
	        rlRun "vmsh run_cmd guest30032 \"iperf -c ${SERVER_GUEST_IP} -p 8080\" "
            rlRun "vmsh run_cmd guest30032 \"ping -n -i 0.001 ${SERVER_GUEST_IP} -c 1000\" "
        else
            test_fail "not client or server, test fail"
        fi
}

bonding_test_xena()
{
	local hostname=`hostname`
    #if [ $hostname == "netqe23.knqe.lab.eng.bos.redhat.com" ] || [ $hostname == "netqe22.knqe.lab.eng.bos.redhat.com" ];then	
    if [ `hostname | grep -P netqe[0-9]+.knqe.lab.eng.bos.redhat.com` ];then
		rlRun "mono /root/Xena2544.exe -c /root/tli_bond.x2544  -e user1"
	else
		if [[ $TRAFFIC_PORT_ONE = *"M9"* ]]; then
            rlRun "mono /root/Xena2544.exe -c /root/hewang_ovs_dpdk_bonding-bj-M9.x2544  -e user1"
        else
            rlRun "mono /root/Xena2544.exe -c /root/hewang_ovs_dpdk_bonding-bj-M5.x2544  -e user1"
        fi

		
	fi	
	sleep 5
	report_file_name=`ls -alt /root/Xena/Xena2544-2G/Reports/xena2544-report*.xml | head -n 1 | awk '{print $NF}'`
	port1_pps=`cat $report_file_name |grep PortRxPps| awk -F ' ' '{printf $10}' | awk -F '"' '{printf $4}'`
	port2_pps=`cat $report_file_name |grep PortRxPps| awk -F ' ' '{printf $10}' | awk -F '"' '{printf $2}'`
	sum_pps=$(($port1_pps+$port2_pps))
	sum_pps=$(($sum_pps/1000000))
	echo $sum_pps
    rlAssertNotEquals "Xena performance test vlaue should be > 0 mpps" "$sum_pps" "0"
	if [ `echo "${sum_pps} > 1" | bc` -ne 0 ];then
        	echo "The rx result is" ${sum_pps}
    else
        	echo "The rx result performance is low, case failed"
    fi
    rlFileSubmit "/root/Xena/Xena2544-2G/Reports/xena2544-report*.xml"
}

bonding_test_trex()
{
        pushd $CASE_PATH
        #get trex server ip 
        rm -f /tmp/conn_is_ok
        timeout -s SIGINT 3 ping $TREX_SERVER_IP -c 3 > /tmp/conn_is_ok
        loss_check=`grep packets /tmp/conn_is_ok | awk '{print $6}'`
        if [ "${loss_check::-1}" == "100" ];then
                echo "trex server "$TREX_SERVER_IP" is no up "
        else
                install_rpms
                init_python_env
                update_ssh_trust
        fi
        wget -q http://netqe-bj.usersys.redhat.com/share/wanghekai/v2.41.tar.gz 
        tar -xvf v2.41.tar.gz > /dev/null 2>&1
        #first use short time quick find the near value and test it long it to find is there any packet loss.
        rlRun "python ./trex_sport.py -c $TREX_SERVER_IP -t 60 --pkt_size=64 -m 10"

        popd
}

check_lacp_status()
{
    sleep 65
    ovs-vsctl show
    ovs-appctl bond/show
    lacp_status=`ovs-appctl bond/show|grep lacp_status| awk -F ': ' '{print $2}'`
    if [ $lacp_status == 'negotiated' ]; then
                echo "---------------------lacp status is negotiated-------------------------"
    else
                echo "---------------------lacp status is not correct----------------------------"
    fi
}

bonding_test_switch()
{

    if i_am_server;then

        rlPhaseStartTest "SERVER_VM_PING_CLIENT_VM_IP_WHERE_TEST_CONN_IS_OK"
        ovs-ofctl dump-ports ovsbr0
        vmsh run_cmd guest30032 "ping ${CLIENT_GUEST_IP} -c 1"
        vmsh run_cmd guest30032 "ping -n -i 0.001 ${CLIENT_GUEST_IP} -c 10000"
        ovs-appctl bond/show
        sync_set client CONN_PING_TEST_READY
        rlPhaseEnd

        rlPhaseStartTest "TEST-OVS-DPDK-BONDING-SWITH-MODE-$BOND_MODE_BALANCE_TCP-PERFORMANCE"
        sync_wait client CLIENT_READY
        if [[ $TRAFFIC_TYPE == "xena" ]]; then
            install_mono_rpm
            download_Xena2544
            bonding_test_xena
        else
            bonding_test_trex   
        fi
        sync_set client SERVER_PERFORMANCE_FINISHED
        rlPhaseEnd

        rlPhaseStartTest "OVS-DPDK-BONDING-SWITCH-$BOND_MODE_BALANCE_TCP-FAILOVER-TEST"
        if [[ $BOND_MODE_BALANCE_TCP == "active-backup" ]]; then
            sync_wait client CLIENT_VM_READY
            destroy_guest
            start_guest
            configure_guest $SERVER_GUEST_IP
            ovs-appctl bond/set-active-slave dpdkbond dpdk0
            check_active_backup_conn
            bonding_active_backup_failover_and_latency
        else
            echo "true"
        fi
        rlPhaseEnd

    elif i_am_client; then

        rlPhaseStartTest "TEST-OVS-DPDK-BONDING-SWITH-MODE-$BOND_MODE_BALANCE_TCP-PERFORMANCE"
        sync_wait server CONN_PING_TEST_READY
        destroy_guest
        start_guest
        guest_start_testpmd
        sync_set server CLIENT_READY
        echo "I AM CLIENT SIDE , I AM READY FOR SERVER PERFORMANCE TEST NOW"
        sync_wait server SERVER_PERFORMANCE_FINISHED
        rlPhaseEnd

        rlPhaseStartTest "OVS-DPDK-BONDING-SWITCH-$BOND_MODE_BALANCE_TCP-FAILOVER-TEST"
        if [[ $BOND_MODE_BALANCE_TCP == "active-backup" ]]; then
            destroy_guest
            start_guest
            configure_guest $CLIENT_GUEST_IP
            sync_set server CLIENT_VM_READY
            ovs-appctl bond/set-active-slave dpdkbond dpdk0
            check_active_backup_conn
        else
            echo "true"
        fi
        rlPhaseEnd


    else
        rlPhaseStartTest "Invalid Host "
        echo "Current Host Role , Please check your config"
        rlPhaseEnd
    fi

}

################################################################################################
update_ssh_trust()
{
        mkdir -p ~/.ssh
        rm -f ~/.ssh/*
        touch ~/.ssh/known_hosts
        chmod 644 ~/.ssh/known_hosts
        ssh-keyscan $TREX_SERVER_IP >> ~/.ssh/known_hosts
        echo 'y\n' | ssh-keygen -f ~/.ssh/id_rsa -t rsa -N ''
        python ssh_trust.py config-ssh-trust ~/.ssh/id_rsa.pub $TREX_SERVER_IP root ${TREX_SERVER_PASSWORD}
}

clear_env()
{   

    systemctl start openvswitch
    ovs-vsctl del-br ovsbr0
    virsh destroy guest30032
    virsh undefine guest30032
    systemctl stop openvswitch
    local bus_list=`dpdk-devbind -s | grep  -E drv=vfio-pci\|drv=igb | awk '{print $1}'`
    for i in $bus_list
    do
        kernel_driver=`lspci -s $i -v | grep Kernel  | grep modules  | awk '{print $NF}'`
        dpdk-devbind -b $kernel_driver $i
    done
}


ovs_tcpdump_install()
{
    rpm -ivh ${PYTHON_OVS_URL} --nodeps
    rpm -ivh ${OVS_TEST_URL} --nodeps
    yum -y install python-pip
	pip install netifaces
}

install_selinux_rpm()
{
	#when enable setforce1, need it
	yum install -y policycoreutils-python
	rpm -ivh http://download-node-02.eng.bos.redhat.com/brewroot/packages/container-selinux/2.36/1.gitff95335.el7/noarch/container-selinux-2.36-1.gitff95335.el7.noarch.rpm
	rpm -ivh http://download-node-02.eng.bos.redhat.com/brewroot/packages/openstack-selinux/0.8.12/0.20171204232656.7e9ef4a.el7ost/noarch/openstack-selinux-0.8.12-0.20171204232656.7e9ef4a.el7ost.noarch.rpm
}

#----------------------------------------------------------
# tests

#The two host need to connect directly:can use netqe23 and netqe16,they connect directly
ovs_dpdk_bond_active_backup()
{
    if i_am_server; then
            rlPhaseStartTest ovs_dpdk_bond_active_backup
            init_physical_topo
            sleep 10
            sync_set client SERVER_START
            rlRun -l "enable_dpdk ${SERVER_NIC1_NAME} ${SERVER_NIC2_NAME}"
            bonding_nic ${SERVER_PMD_CPU_MASK} ${BOND_MODE_ACTIVE_BACKUP}
        	ovs-appctl bond/set-active-slave dpdkbond dpdk0
            sleep 3
    	    echo "after configure active port dpdk0"
            ovs-appctl bond/show
            vcpupin_in_xml $SERVER_NUMA $SERVER_VCPUS guest_${GUEST_IMG}.xml g1.xml server
            start_guest
            configure_guest ${SERVER_GUEST_IP}
            sync_wait client CLIENT_TEST
            bonding_test_active_backup
            rlPhaseEnd

    elif i_am_client;then
            rlPhaseStartTest ovs_dpdk_bond_active_backup
            sync_wait server SERVER_START
            rlRun -l "enable_dpdk ${CLIENT_NIC1_NAME} ${CLIENT_NIC2_NAME}"
            bonding_nic ${CLIENT_PMD_CPU_MASK} ${BOND_MODE_ACTIVE_BACKUP}
            ovs-appctl bond/set-active-slave dpdkbond dpdk0
        	echo "after configure active port dpdk0"
            ovs-appctl bond/show
            vcpupin_in_xml $CLIENT_NUMA $CLIENT_VCPUS guest_${GUEST_IMG}.xml g1.xml client
            start_guest
            configure_guest ${CLIENT_GUEST_IP}
            sync_set server CLIENT_TEST
            bonding_test_active_backup
            rlPhaseEnd
    else
            test_fail "not client or server, test fail"
    fi

}

#The two host need to connect directly:can use netqe23 and netqe16, they connect directly
ovs_dpdk_bond_balance_tcp()
{
    if i_am_server; then
        rlPhaseStartTest ovs_dpdk_bond_balance_tcp
        init_physical_topo
        sleep 5
        sync_set client SERVER_START
        rlRun -l "enable_dpdk ${SERVER_NIC1_NAME} ${SERVER_NIC2_NAME}"
    	rlRun "bonding_nic ${SERVER_PMD_CPU_MASK} ${BOND_MODE_BALANCE_TCP}"
        ovs-vsctl set port dpdkbond lacp=passive
        sync_wait client LACP_SET_OK
        sleep 70
        ovs-appctl bond/show

        nic3_businfo=$(ethtool -i ${SERVER_NIC1_XENA} | grep "bus-info" | awk  '{print $2}')
        nic4_businfo=$(ethtool -i ${SERVER_NIC2_XENA} | grep "bus-info" | awk  '{print $2}')
        echo "nic1_businfo is" $nic1_businfo
        echo "nic2_businfo is" $nic2_businfo
        echo "nic3_businfo is" $nic3_businfo
        echo "nic4_businfo is" $nic4_businfo
        local nic3_mac=$(ethtool -P ${SERVER_NIC1_XENA} | awk '{print $NF}')
        local nic4_mac=$(ethtool -P ${SERVER_NIC2_XENA} | awk '{print $NF}')
        rlRun -l "enable_dpdk ${SERVER_NIC1_XENA} ${SERVER_NIC2_XENA}"
        if [[ "$nic3_businfo" == "$nic4_businfo" ]]; then
            ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=class=eth,mac=${nic3_mac}
            ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=class=eth,mac=${nic4_mac}

        else
            ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=${nic3_businfo}
            ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=${nic4_businfo}
        fi
        ovs-vsctl show


        rlRun "vcpupin_in_xml $SERVER_NUMA $SERVER_VCPUS guest_${GUEST_IMG}.xml g1.xml server"
        rlRun "start_guest"
        rlRun "configure_guest ${SERVER_GUEST_IP}"
        sync_wait client CLIENT_TEST
        if [ ${BOND_MODE_BALANCE_TCP} == "balance-slb" ];then
                bonding_test_balance_slb
        else
                bonding_test_balance_tcp
        fi
        
        rlPhaseEnd
                
    elif i_am_client;then
        rlPhaseStartTest ovs_dpdk_bond_balance_tcp
        sync_wait server SERVER_START 
        rlRun -l "enable_dpdk ${CLIENT_NIC1_NAME} ${CLIENT_NIC2_NAME}"
        rlRun "bonding_nic ${CLIENT_PMD_CPU_MASK} ${BOND_MODE_BALANCE_TCP}"
    	ovs-vsctl set port dpdkbond lacp=active
        sync_set server LACP_SET_OK
        sleep 70
        ovs-appctl bond/show
        rlRun "vcpupin_in_xml $CLIENT_NUMA $CLIENT_VCPUS guest_${GUEST_IMG}.xml g1.xml client"
        rlRun "start_guest"
        rlRun "configure_guest ${CLIENT_GUEST_IP}"
        sync_set server CLIENT_TEST
        if [ ${BOND_MODE_BALANCE_TCP} == "balance-slb" ];then
                bonding_test_balance_slb
        else
                bonding_test_balance_tcp
        fi
        rlPhaseEnd
    else
        test_fail "not client or server, test fail"
    fi
}

ovs_dpdk_bond_active_backup_traffic_all()
{

        rlRun "install_mono_rpm"

        if i_am_server; then
                rlPhaseStartTest ovs_dpdk_bond_active_backup_traffic_all
                init_physical_topo
                sleep 5
                sync_set client SERVER_START
                rlRun -l "enable_dpdk ${SERVER_NIC1_NAME} ${SERVER_NIC2_NAME}"
                rlRun "bonding_nic ${SERVER_PMD_CPU_MASK} ${BOND_MODE_ACTIVE_BACKUP}"
                nic3_businfo=$(ethtool -i ${SERVER_NIC1_XENA} | grep "bus-info" | awk  '{print $2}')
                nic4_businfo=$(ethtool -i ${SERVER_NIC2_XENA} | grep "bus-info" | awk  '{print $2}')
                echo "nic1_businfo is" $nic1_businfo
                echo "nic2_businfo is" $nic2_businfo
                echo "nic3_businfo is" $nic3_businfo
                echo "nic4_businfo is" $nic4_businfo
                local nic3_mac=$(ethtool -P ${SERVER_NIC1_XENA} | awk '{print $NF}')
                local nic4_mac=$(ethtool -P ${SERVER_NIC2_XENA} | awk '{print $NF}')
                rlRun -l "enable_dpdk ${SERVER_NIC1_XENA} ${SERVER_NIC2_XENA}"
                if [[ "$nic3_businfo" == "$nic4_businfo" ]]; then
                    ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=class=eth,mac=${nic3_mac}
                    ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=class=eth,mac=${nic4_mac}

                else
                    rlRun "ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=${nic3_businfo}"
                    rlRun "ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=${nic4_businfo}"
                fi
                ovs-vsctl show
                ovs-appctl bond/set-active-slave dpdkbond dpdk0
                ovs-appctl bond/show
                sync_wait client CLIENT_TEST
                #this time we should check the active-backup bond conn               
                ip li set whk up 
                ip ad ad 192.168.30.100/24 dev whk
                ping -c 3 192.168.30.101 -W 5 || ovs-appctl bond/set-active-slave dpdkbond dpdk1
                if [ $THROUGH_PUT_TRAFFIC_TYPE == "xena" ];then
                        download_Xena2544
                        bonding_test_xena
                else
                        bonding_test_trex
                fi
                rlPhaseEnd

        elif i_am_client;then
                rlPhaseStartTest ovs_dpdk_bond_active_backup_traffic_all
                sync_wait server SERVER_START 
                rlRun -l "enable_dpdk ${CLIENT_NIC1_NAME} ${CLIENT_NIC2_NAME}"
                rlRun "bonding_nic ${CLIENT_PMD_CPU_MASK} ${BOND_MODE_ACTIVE_BACKUP}"
                ovs-appctl bond/set-active-slave dpdkbond dpdk0
                ovs-appctl bond/show
                rlRun "vcpupin_in_xml $CLIENT_NUMA $CLIENT_VCPUS guest_${GUEST_IMG}.xml g1.xml client"
                rlRun "start_guest"
                ovs-appctl bond/set-active-slave dpdkbond dpdk0
                ovs-appctl bond/show
                rlRun "guest_start_testpmd"
                ovs-appctl bond/set-active-slave dpdkbond dpdk0
                ovs-appctl bond/show
                ip li set whk up 
                ip ad ad 192.168.30.101/24 dev whk
                sync_set server CLIENT_TEST
                rlPhaseEnd

        else
            rlPhaseStartTest ovs_dpdk_bond_active_backup_traffic_all
                test_fail "not client or server, test fail"
            rlPhaseEnd
        fi
}


#The two host need to connect to the same switch: can use dell-01 and dell-02, they connect to switch5010
ovs_dpdk_bond_balance_tcp_switch()
{

    swname=$SWITCH_NAME
    server_swport=$SERVER_SWPORT
    server_port1=$SERVER_SWPORT_ONE
    server_port2=$SERVER_SWPORT_TWO
    client_swport=$CLIENT_SWPORT
    client_port1=$CLIENT_SWPORT_ONE
    client_port2=$CLIENT_SWPORT_TWO
    rlRun "ovs_tcpdump_install"

    if i_am_server; then
        rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: switch configure active mode and dpdk configure passive mode"
        
        echo "configure xnea connect to switch 5010 3 4 5 6"
        init_physical_topo
        sleep 20
        ip li set ${SERVER_NIC1_NAME} up
        ip li set ${SERVER_NIC2_NAME} up
        echo "configure two ports of switch to channel and enable active mode"
        rlRun  "swcfg port_down $swname $server_port1"
        rlRun  "swcfg port_down $swname $server_port2"
    	rlRun  "swcfg port_up $swname $server_port1"
        rlRun  "swcfg port_up $swname $server_port2"
        sleep 5
        unset SW_BONDING_ID
        SW_BONDING_ID=3
        rlRun  "swcfg cleanup_port_channel $swname \"$server_swport\"" "0,1"
        sleep 2
        rlRun  "swcfg setup_port_channel   $swname \"$server_swport\" \"active\""
        #sync_set client SERVER_START
        echo "configure two ports of server enable dpdk"
        rlRun -l "enable_dpdk ${SERVER_NIC1_NAME} ${SERVER_NIC2_NAME}"
        echo "configure ovs on server"
        bonding_nic ${SERVER_PMD_CPU_MASK} ${BOND_MODE_BALANCE_TCP}
        nic3_businfo=$(ethtool -i ${SERVER_NIC1_XENA} | grep "bus-info" | awk  '{print $2}')
        nic4_businfo=$(ethtool -i ${SERVER_NIC2_XENA} | grep "bus-info" | awk  '{print $2}')
        echo "nic1_businfo is" $nic1_businfo
        echo "nic2_businfo is" $nic2_businfo
        echo "nic3_businfo is" $nic3_businfo
        echo "nic4_businfo is" $nic4_businfo
        local nic3_mac=$(ethtool -P ${SERVER_NIC1_XENA} | awk '{print $NF}')
        local nic4_mac=$(ethtool -P ${SERVER_NIC2_XENA} | awk '{print $NF}')

        rlRun -l "enable_dpdk ${SERVER_NIC1_XENA} ${SERVER_NIC2_XENA}"
        if [[ "$nic3_businfo" == "$nic4_businfo" ]]; then
            ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=class=eth,mac=${nic3_mac}
            ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=class=eth,mac=${nic4_mac}

        else
            ovs-vsctl add-port ovsbr0 dpdk2 -- set Interface dpdk2 type=dpdk options:dpdk-devargs=${nic3_businfo}
            ovs-vsctl add-port ovsbr0 dpdk3 -- set Interface dpdk3 type=dpdk options:dpdk-devargs=${nic4_businfo}
        fi


        ovs-vsctl show
        ovs-appctl bond/show

        echo "configure dpdkbond to passive mode"
        ovs-vsctl set port dpdkbond lacp=passive
        echo "check the lacp status after configure two ports of switch enable active mode and dpdkbond as passive mode"
    	check_lacp_status

    	rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check whether has LACP packet"

        echo "catch the packet to check whether contain LACP packet"
        timeout 10 ovs-tcpdump -i dpdkbond -vv|grep LACP
    	if [ $? -eq 0 ]
    	then
    		echo "Can catch LACP traffic"
    	else
    		echo "Cannot catch LACP traffic"
    	fi

    	rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: switch configure passive mode and dpdk configure active mode"
            
        echo "modify the two ports of switch to channel and enable passive mode"
        rlRun  "swcfg cleanup_port_channel $swname \"$server_swport\"" "0,1"
        rlRun  "swcfg setup_port_channel $swname \"$server_swport\" \"passive\""
        echo "configure dpdkbond to active mode"
        ovs-vsctl set port dpdkbond lacp=active
        echo "check the lacp status after configure two ports of switch enable passive mode and dpdkbond as active mode"
        check_lacp_status 

    	rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure lacp-time=fast"
        
        echo "configure lacp-time=fast"
    	ovs-vsctl set port dpdkbond other_config:lacp-time=fast
        echo "check the lacp status after configure lacp-time=fast"
    	check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure lacp-time=slow"
    	
        ovs-vsctl del-port midpdkbond
        echo "configure lacp-time=slow"
    	ovs-vsctl set port dpdkbond other_config:lacp-time=slow
        echo "check the lacp status after configure lacp-time=slow"
    	check_lacp_status
    	
        rlPhaseEnd
    	
    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure bond-detect-mode=miimon and bond-miimon-interval=100"
        
        echo "configure ovs bond-detect-mode=miimon and bond-miimon-interval=100"
    	ovs-vsctl set port dpdkbond other_config:bond-detect-mode=miimon
    	ovs-vsctl set port dpdkbond other_config:bond-miimon-interval=100
        echo "check the lacp status after after configure bond-detect-mode=miimon and bond-miimon-interval=100"
    	check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check ping test when down one port of switch"
        sync_set client SERVER_START
        echo "configure guest.xml"
    	rlRun "vcpupin_in_xml $SERVER_NUMA $SERVER_VCPUS guest_${GUEST_IMG}.xml g1.xml server"
        echo "start guest"
        rlRun "start_guest"
        echo "configure guest"
        rlRun "configure_guest ${SERVER_GUEST_IP}"
        sync_wait client CLIENT_TEST
        echo "start bonding_test"
        rlRun -l "bonding_test_switch"

        rlPhaseEnd


    elif i_am_client;then
        rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: switch configure active mode and dpdk configure passive mode"
    	
        sync_wait server SERVER_START
    	echo "configure two ports of switch to channel and enable active mode"
        swcfg port_down $swname $client_port1
        swcfg port_down $swname $client_port2
    	swcfg port_up $swname $client_port1
        swcfg port_up $swname $client_port2
        sleep 5
        unset SW_BONDING_ID
        SW_BONDING_ID=4
        rlRun  "swcfg cleanup_port_channel $swname \"$client_swport\"" "0,1"
        sleep 2
        rlRun  "swcfg setup_port_channel   $swname \"$client_swport\" \"active\""
        sleep 3
        ip li set ${CLIENT_NIC1_NAME} up
        ip li set ${CLIENT_NIC2_NAME} up
        sleep 3
        echo "configure two ports of server enable dpdk"
        rlRun -l "enable_dpdk ${CLIENT_NIC1_NAME} ${CLIENT_NIC2_NAME}"
        echo "configure ovs on server"
        bonding_nic ${CLIENT_PMD_CPU_MASK} ${BOND_MODE_BALANCE_TCP}
    	echo "configure dpdkbond to passive mode"       
        ovs-vsctl set port dpdkbond lacp=passive
    	echo "check the lacp status after configure two ports of switch enable active mode and dpdkbond as passive mode"
    	check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check whether has LACP packet"
    	
        echo "catch the packet to check whether contain LACP packet"
    	timeout 10 ovs-tcpdump -i dpdkbond -vv|grep LACP
    	if [ $? -eq 0 ];then
            echo "Can catch LACP traffic"
        else
            echo "Cannot catch LACP traffic"
            exit 1
    	fi
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: switch configure passive mode and dpdk configure active mode"
    	
        echo "modify the two ports of switch to channel and enable passive mode"
        rlRun "swcfg cleanup_port_channel $swname \"$client_swport\"" "0,1"
    	rlRun "swcfg setup_port_channel $swname \"$client_swport\" \"passive\""
    	echo "configure dpdkbond to active mode"
        ovs-vsctl set port dpdkbond lacp=active
    	echo "check the lacp status after configure two ports of switch enable passive mode and dpdkbond as active mode"
    	check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure lacp-time=fast"
    	
        echo "configure lacp-time=fast"
    	ovs-vsctl set port dpdkbond other_config:lacp-time=fast
    	echo "check the lacp status after configure lacp-time=fast"
    	check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure lacp-time=slow"
    	
        ovs-vsctl del-port midpdkbond
    	echo "configure lacp-time=slow"
    	ovs-vsctl set port dpdkbond other_config:lacp-time=slow
    	echo "check the lacp status after configure lacp-time=slow"
        check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check lacp status after configure bond-detect-mode=miimon and bond-miimon-interval=100"
    	echo "configure ovs bond-detect-mode=miimon and bond-miimon-interval=100"
    	ovs-vsctl set port dpdkbond other_config:bond-detect-mode=miimon
        ovs-vsctl set port dpdkbond other_config:bond-miimon-interval=100
    	echo "check the lacp status after after configure bond-detect-mode=miimon and bond-miimon-interval=100"
        check_lacp_status
    	
        rlPhaseEnd

    	rlPhaseStartTest "ovs_dpdk_bond_balance_tcp_switch test: check ping test when down one port of switch"
    	echo "configure guest.xml"
    	vcpupin_in_xml $CLIENT_NUMA $CLIENT_VCPUS guest_${GUEST_IMG}.xml g1.xml client
    	echo "start guest"
        start_guest
    	echo "configure guest"	
        configure_guest ${CLIENT_GUEST_IP}
        sync_set server CLIENT_TEST
    	echo "start bonding_test"
        rlRun -l "bonding_test_switch"
            
        rlPhaseEnd
    else
            test_fail "not client or server, test fail"
    fi
	
}

if i_am_server;then
        SERVER_NUMA=$(cat /sys/class/net/${SERVER_NIC1_NAME}/device/numa_node)
        #ISOLCPUS_SERVER=$(cat /sys/class/net/${SERVER_NIC1_NAME}/device/local_cpulist)
        ISOLCPUS_SERVER=`get_isolate_cpus $SERVER_NIC1_NAME`
        #may be 0,2,4,6
        #may be 1,3,5,7
        #may be 0-9,10-19
        #SERVER_PMD_CPU_MASK=`cat /sys/class/net/${SERVER_NIC1_NAME}/device/local_cpus | sed s/,//g | sed 's/^0*//g'`
        SERVER_PMD_CPU_MASK=`get_pmd_masks $ISOLCPUS_SERVER`
elif i_am_client;then
        CLIENT_NUMA=$(cat /sys/class/net/${CLIENT_NIC1_NAME}/device/numa_node)
        #ISOLCPUS_CLIENT=$(cat /sys/class/net/${CLIENT_NIC1_NAME}/device/local_cpulist)
        ISOLCPUS_CLIENT=`get_isolate_cpus ${CLIENT_NIC1_NAME}`
        #CLIENT_PMD_CPU_MASK=`cat /sys/class/net/${CLIENT_NIC1_NAME}/device/local_cpus | sed 's/,//g' | sed 's/^0*//g'`
        CLIENT_PMD_CPU_MASK=`get_pmd_masks $ISOLCPUS_CLIENT`
else
        echo "error server role"
        true
fi

echo "SERVER NUMA IS "$SERVER_NUMA
echo "SERVER ISOLATED CPUS IS "$ISOLCPUS_SERVER
echo "SERVER PMD CPU MASK IS "$SERVER_PMD_CPU_MASK
echo "CLIENT NUMA IS "$CLIENT_NUMA
echo "CLIENT ISOLATED CPUS IS "$ISOLCPUS_CLIENT
echo "CLIENT PMD CPU MASK IS "$CLIENT_PMD_CPU_MASK


rlJournalStart
rlPhaseStartSetup

if ! ls /tmp/TASK*; then
	rlRun "add_yum_profiles"
	rlRun "install_rpms"
	if [ $RHEL = "74" ];then
		sed -i '/baseurl=/c\baseurl=http://download.eng.bos.redhat.com/rel-eng/RHEL-7.4-20170504.0/compose/Server/x86_64/os' /etc/yum.repos.d/beaker-Server.repo
		yum install -y kernel-3.10.0-663.el7.x86_64
	fi
	rlRun "touch /tmp/TASK1"
	rlRun "config_hugepage"
fi

rlPhaseEnd

rlPhaseStartTest "start bonding test"
if [ -f /tmp/TASK1 ]; then
	rlRun "cat /proc/cmdline"
	rlRun "install_ovs"
	version=`rpm -qa|grep openvswitch | awk -F '-' '{print $2}'`
	if [[ $version =~ "2.9."[0-9] ]];then
            install_selinux_rpm
            setenforce 1
    else
            setenforce 0
    fi
    setenforce 0
    if [[ "$NIC_DRIVER" == "nfp" ]]; then
        setenforce 0
    fi

    if [[ $CUSTOMER_PFT == "true" ]];then
        BOND_TYPE=bond_active_balance_tcp_switch
        unset BOND_MODE_BALANCE_TCP
        BOND_MODE_BALANCE_TCP="balance-tcp"
        rlRun "ovs_dpdk_bond_balance_tcp_switch"
        unset BOND_MODE_BALANCE_TCP
        BOND_MODE_BALANCE_TCP="active-backup"
        clear_env
        rlRun "ovs_dpdk_bond_balance_tcp_switch"
    else
        #here
        if [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "bond_balance_tcp" ];then
            rlRun "ovs_dpdk_bond_balance_tcp"
        elif [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "bond_balance_slb" ];then
            BOND_MODE_BALANCE_TCP="balance-slb"
            rlRun "ovs_dpdk_bond_balance_tcp"
        elif [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "bond_active_backup" ];then
            rlRun "ovs_dpdk_bond_active_backup"
        elif [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "bond_active_backup_xena" ];then
            GUEST_TESTPMD_Q_NUM=1
            rlRun "ovs_dpdk_bond_active_backup_traffic_all"
        elif [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "bond_active_balance_tcp_switch" ];then
            unset BOND_MODE_BALANCE_TCP
            BOND_MODE_BALANCE_TCP="balance-tcp"
            rlRun "ovs_dpdk_bond_balance_tcp_switch"
            unset BOND_MODE_BALANCE_TCP
            BOND_MODE_BALANCE_TCP="active-backup"
            clear_env
            rlRun "ovs_dpdk_bond_balance_tcp_switch"
        elif [ -n "$BOND_TYPE" ] && [ "$BOND_TYPE" = "all" ];then
           rlRun "ovs_dpdk_bond_balance_tcp"
           rlRun "ovs_dpdk_bond_active_backup"
           rlRun "ovs_dpdk_bond_active_backup_traffic_all"

        else
           echo "wrong BOND_TYPE"
        fi

    fi

fi

rlPhaseEnd

rlJournalPrintText
rlJournalEnd
