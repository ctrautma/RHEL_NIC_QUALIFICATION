#!/usr/bin/env python

import base64
import paramiko


def config_ssh_trust(file_name,remote_host,username,password):
	client = paramiko.SSHClient()
	client.load_system_host_keys()
	#client.set_missing_host_key_policy(paramiko.WarningPolicy())
	client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	with open(file_name,"r") as fd:
	    kaizi = fd.read()
	client.connect(remote_host,username=username, password=password)
	client.exec_command("mkdir -p /root/.ssh/")
	client.exec_command('test -f /root/.ssh/known_hosts || touch /root/.ssh/known_hosts')
	cmd = "echo %s >> /root/.ssh/authorized_keys" % (kaizi.strip('\n'))
	client.exec_command(cmd)
	client.close()

import fire
if __name__ == "__main__":
	fire.Fire()

