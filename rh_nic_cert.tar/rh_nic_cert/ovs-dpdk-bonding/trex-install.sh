#!/bin/bash

# this shell do install trex on a machine that role is trex traffic generator
# user must config your repository for rhel and keep the below require packages install right
# ****************************************
# dpdk 
# dpdk-tools
# gcc git lshw pciutils 
# python-devel 
# python-setuptools 
# python-pip
# tuned-profiles-cpu-partitioning 
# wget
#****************************************
#usage 
# 1. config nic_bus var , you can use "lspci | grep Eth " command to select which cards that you want to use
# 2. config trex tar pacakge url,you'd better use the v2.41 version.
# 3. run this shell and system will be reboot
# 4. check the command line with command 'cat /proc/cmdline' when the system reboot already
# 5. start your trex server process

# Note: if you use mellanox cards which supports dpdk 
# please refer https://trex-tgn.cisco.com/trex/doc/trex_appendix_mellanox.html

#author wanghekai hewang@redhat.com


#subscription-manager register --serverurl=subscription.rhsm.stage.redhat.com:443/subscription --baseurl=https://cdn.redhat.com --username=qa@redhat.com --password=redhatqa --auto-attach

#config var with below 
nic_bus="05:00.0 05:00.1"
trex_tar_url="http://netqe-bj.usersys.redhat.com/share/wanghekai/v2.41.tar.gz"
###############################################################################
# below code do not need fix unless there is a bug
###############################################################################

usage()
{
	echo "first config the pci address of network interface cards "
	echo "example nic_bus=\"05:00.0 05:00.1\" and so on "
	echo "for detail information please refer this file comment"
}

install_packages()
{
	#rhel-7-server-extras-rpms
	#rhel-7-server-rpms
	#subscription-manager repos --enable=rhel-7-fast-datapath-rpms
	[ -z `rpm -qa | grep epel-release` ] && yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm	
	subscription-manager repos --enable rhel-7-server-extras-rpms

	yum clean all
	yum makecache
	all_package="dpdk
				 dpdk-tools
				 gcc
				 git 
				 lshw 
				 pciutils 
				 python-devel 
				 python-setuptools 
				 python-pip
				 tuned-profiles-cpu-partitioning 
				 wget"
	for pack in $all_package
	do
		echo "Install $pack begin now"
		yum -y install $pack
		echo "Install $pack end "
	done
}

trex_install()
{
	wget ${trex_tar_url}
	
	tar_name=${trex_tar_url##*/}
	tar_version=${tar_name%%.tar.gz}

	tar -xvf ${tar_name}
	pushd ${tar_version}
	conf_file=/etc/trex_cfg.yaml
	[ -f $conf_file ] && rm -f $conf_file
	./dpdk_setup_ports.py -c $nic_bus --force-macs --no-ht -o $conf_file
	popd
}

update_system()
{
	sed -i -e 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="default_hugepagesz=1G hugepagesz=1G hugepages=32 iommu=pt intel_iommu=on /'  /etc/default/grub
	isolate_cpus=`grep threads /etc/trex_cfg.yaml  | awk '{print $NF}' | tr -d []`
	systemctl enable tuned
	systemctl start tuned
	echo isolated_cores=${isolate_cpus} > /etc/tuned/cpu-partitioning-variables.conf
	tuned-adm profile cpu-partitioning
	grub2-mkconfig -o /boot/grub2/grub.cfg
}

install_packages
trex_install
update_system
echo "System update finished "
echo "please reboot your system if there is no other problem find"
reboot