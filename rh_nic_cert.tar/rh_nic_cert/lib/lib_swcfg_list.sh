#!/bin/sh

###############################################################################
#
# switches definition
# NOTE
#    1. blank field in each available row is NOT allowed
#    2. when duplicate name, only the first match is used
#
swlist=${SW_LIST:-'
#sw_name    sw_os    sw_url                 sw_pw
#name       os       user@IP                password
#---------------------------------------------------

6004        nxos     admin@10.73.130.12     100yard-
5010        nxos     redhat@10.73.130.14    kernel-qe
5010-2      nxos     admin@10.19.15.32      100yard-
5020        nxos     ------                 100yard-
5548        nxos     admin@10.73.130.8      100yard-
5548-2      nxos     admin@10.73.130.9      100yard-

3560        ios      redhat@10.73.130.15    kernel-qe
3750        ios      redhat@10.73.130.6     kernel-qe
3750-2      ios      admin@10.73.130.11     100yard-

#4550        junos    root@10.73.130.13      100yard-
4550        junos    netqe@10.73.130.13     kernel-qe
#4550-3      junos    root@10.73.130.18      100yard-
4550-3      junos    netqe@10.73.130.18     kernel-qe
#5200-2      junos    root@10.73.130.20      100yard-
5200-2      junos    netqe@10.73.130.20     kernel-qe

4550-2      junos    root@10.19.15.28       100yard-
5200        junos    root@10.19.15.66       100yard-
4550-4      junos    root@10.19.15.68       100yard-
5100-2      junos    root@10.19.15.21       100yard-
5100-1      junos    root@10.19.15.20       100yard-
4200        junos    root@10.19.15.67       100yard-
4600        junos    root@10.19.17.88       100yard-
'}

