#!/bin/bash - 

#
# bonding test, like lacp needs a switch connected to linux machine
# and bonding settings are needed in the switch
# helper functions below are used in the test to setup switch
#
# so, if bonding test are enabled
# adapting functions below to your test environment is a must
#
# ${NETWORK_COMMONLIB_DIR} is only used in Red hat netowrk-qe lab
# which would never be defined in partner's lab

if [[ ! ${NETWORK_COMMONLIB_DIR+x} ]]
then
	# get_iface_sw_port
	# is to get switch port by linux interface
	# the function is only used in partner's lab
	# $1: list of linux network interfaces to query for the switch ports
	# $2: bash variable to save switch name
	# $3: bash variable to save the queried result
	#
	# This function is used only by functions below in this file
	# No need to implement it if functions below don't use it
	#
	# Example
	# get_iface_sw_port 'eth1 eth2' swname swport
	# swname will be the switch name
	# swport will be the list of switch ports connected to linux interfaces
	#

	get_iface_sw_port()
	{
		local list_of_ifaces=$1
		local nic=($NIC_TEST)
		local swp=($SW_PORT)
		local list_of_swports=''

		for iface in $list_of_ifaces
		do
			for ((i=0; i<$(wc -w <<< $NIC_TEST); i++))
			do
			if [ "${nic[i]}" = "$iface" ]
			then
				[ -z "$list_of_swports" ] && list_of_swports="${swp[i]}" || list_of_swports="${list_of_swports} ${swp[i]}"
				break
			fi
			done
		done
		eval "$2=$SW_NAME; $3='$list_of_swports'"
	}
fi

#
# Enable switch port connected to interface on linux server
# 
# $iface is the interface name in linux, like eth0
#
# Example
# swcfg_port_up_by_linux_iface eth0
#
swcfg_port_up_by_linux_iface()
{
	local iface=$1

	local swname=""
	local swport=""

	get_iface_sw_port "$iface" swname swport
	echo "swcfg port_up $swname $swport"
	swcfg port_up $swname $swport
}

#
# Disable switch port connected to interface on linux
# 
# $iface is the interface name in linux, like eth0
#
# Example
# swcfg_port_down_by_linux_iface eth0
#
swcfg_port_down_by_linux_iface()
{
	local iface=$1

	local swname=""
	local swport=""

	get_iface_sw_port "$iface" swname swport
	echo "swcfg port_down $swname $swport"
	swcfg port_down $swname $swport
}

#
# setup bonding on switch
#    1. create a bonding channel on the switch
#    2. add the required list of interfaces in $1 to the created bond channel
#    3. enable lacp and set it to the required mode $2
#    4. set it to vlan trunk mode, encapsulation 802.1q, and allow vlan 1 ~ 100
#
# $1: is the list of interfaces on linux in a bonding channel, like 'eth0 eth1'
# $2: lacp mode active or passive
#
# Example
# swcfg_setup_bonding_by_linux_ifaces 'eth0 eth1' active
#
swcfg_setup_bonding_by_linux_ifaces()
{
	local ifaces_list="$1"
	local lacp_mode=$2

	local swname=""
	local swport=""

	get_iface_sw_port "$ifaces_list" swname swport
	echo "swcfg setup_port_channel $swname '$swport' $lacp_mode"
	swcfg setup_port_channel $swname "$swport" "$lacp_mode"
}

#
# Cleanup bonding settings for the required interface list on switch
#
# $1 is the list of interfaces on linux in a bonding channel, like 'eth0 eth1'
#
# Example
# swcfg_cleanup_bonding_by_linux_ifaces 'eth0 eth1'
#
swcfg_cleanup_bonding_by_linux_ifaces()
{
	local ifaces_list="$1"

	local swname=""
	local swport=""

	get_iface_sw_port "$ifaces_list" swname swport
	echo "swcfg cleanup_port_channel $swname '$swport'"
	swcfg cleanup_port_channel $swname "$swport"
}


