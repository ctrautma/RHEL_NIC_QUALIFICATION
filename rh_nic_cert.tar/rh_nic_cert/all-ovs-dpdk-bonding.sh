#!/bin/bash
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2013 Red Hat, Inc.
#   Author : hewang@redhat.com
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#####################################
# Settings for test

# root directory for the test suite ,may be set manually
CASE_PATH=${CASE_PATH:-"$(dirname $(readlink -f $0))"}

#Physical Topo
#for ovs dpdk bonding (A/B,SLB,TCP) mode
#
#                                +-------------------------------+               +---------------------------------------+
#                                |DUT Server    /---vhostuser    |               |Host Client      |-----------------|   |
#                                |           OvsBr0              |NIC Port       |       OvsBr0    |VM dpdk          |   |
#                                |            | | |              |               |       | | |     |testpmd macswap  |   |
#+---------------+NIC Port1      | /----------| | |--------------|---------------|-------| | \     |     |           |   |
#|               |---------------|/           | | |DPDK Bond     |NIC Port       |DPDK bond|  \ vhostuser|           |   |
#|Traffic Trex   |               |  /---------| | |--------------|---------------|---------|   \---|-----|           |   |
#|   Host        |NIC Port2      | / +----------|---------+      |               |---------        |-----------------|   |
#|               |---------------|/  |vm testpmd macswap  |      |               |                                       |
#+---------------+               |   +--------------------+      |               |                                       |
#                                +-------------------------------+               +---------------------------------------+
#
#
#for ovs dpdk bonding lacp mode
#
# +--------------+
# |              |+----------------------------------------------------------+
# |              |                                                           |
# |normal switch |+------------------------------------------------------+   |
# |              |                                                       |   |
# |              |+---------------------------------------------------+  |   |
# |              |                                                    |  |   |
# |              |+------------------------------------------------+  |  |   |
# |              |                                                 |  |  |   |
# +--------------+                                                 |  |  |   |
#                                                                  |  |  |   |
#                                                                  |  |  |   |
#                                                                  |  |  |   |
#                                                                  |  |  |   |
#                                +-------------------------------+ |  |  |   |   +---------------------------------------+
#                                |DUT Server    /---vhostuser    | |  |  |   |   |Host Client      |-----------------|   |
#                                |           OvsBr0              | |  |  |   |   |       OvsBr0    |VM dpdk          |   |
#                                |            | | |              | |  |  |   |   |         | |     |testpmd macswap  |   |
#+---------------+NIC Port1      | /----------| | |--------------|-+  |  |   +---|---------| \     |     |           |   |
#|               |---------------|/           | | |DPDK Bond     |    |  |       |DPDK bond|  \ vhostuser|           |   |
#|Traffic Trex   |               |  /---------| | |--------------|----+  +---------|-------|   ----|-----|           |   |
#|   Host        |NIC Port2      | / +----------|---------+      |               |                 |-----------------|   |
#|               |---------------|/  |vm testpmd macswap  |      |               |                                       |
#+---------------+               |   +--------------------+      |               |                                       |
#                                +-------------------------------+               +---------------------------------------+
#
#
#
#
#NOTE PLEASE KEEP CUSTOMER_PFT FIXED
CUSTOMER_PFT=true
#PLEASE KEEP THE FOLLOW SECTION CONFIG FIXED
#################################################################
SERVER_VCPUS=${SERVER_VCPUS:-2}
CLIENT_VCPUS=${CLIENT_VCPUS:-2}
CLIENT_GUEST_IP=${CLIENT_GUEST_IP:-192.168.99.200}
SERVER_GUEST_IP=${SERVER_GUEST_IP:-192.168.99.201}
BOND_MODE_ACTIVE_BACKUP=${BOND_MODE_ACTIVE_BACKUP:-active-backup}
BOND_MODE_BALANCE_TCP=${BOND_MODE_BALANCE_TCP:-balance-tcp}
RHEL=${RHEL:-"75"}

##################################################################
#NOTICE PLEASE FIX YOUR CONFIG FROM HERE BELOW

#CONN_TYPE describe the physical topo connection Can be config the following item
#netscout : connect with netscout
#direct : connet directly
#switch : The all host connect to a switch
CONN_TYPE=${CONN_TYPE:-netscout}
#traffic_type ,can  be xena trex
TRAFFIC_TYPE=${TRAFFIC_TYPE:-xena}
THROUGH_PUT_TRAFFIC_TYPE=${TRAFFIC_TYPE}


# hostname for the machines
# The name must be the same as shown by linux command hostname
# and the names for CLIENTS and SERVERS must not be the same
SERVERS=${SERVERS:-"dell-per730-54.rhts.eng.pek2.redhat.com"}
CLIENTS=${CLIENTS:-"dell-per730-55.rhts.eng.pek2.redhat.com"}
SW_LIST=${SW_LIST:='5010     nxos   redhat@10.73.130.14   kernel-qe'}
SW_BONDING_ID=${SW_BONDING_ID:-"1"}


################################################################################
#TRAFFIC TREX CONFIG 
#ONLY ENABLED WITH TRAFFIC_TYPE==trex
#the host ip that  started the t-rex-64 -i with this host
TREX_SERVER_IP=${TREX_SERVER_IP:-10.73.130.211}
TREX_SERVER_PASSWORD=${TREX_SERVER_PASSWORD:-QwAo2U6GRxyNPKiZaOCx}

#TOPO PORT NAME
#NOTE: IF Your environment is NOT connect with netscout , do not fill the following item
#THE FOLLOWING SECTION ITME ONLY ENABLED WITH NETSCOUT
TRAFFIC_PORT_ONE=${TRAFFIC_PORT_ONE:-Xena_M5P0}
TRAFFIC_PORT_TWO=${TRAFFIC_PORT_TWO:-Xena_M5P1}
SERVER_TRAFFIC_PORT_ONE=${SERVER_TRAFFIC_PORT_ONE:-01.01.05}
SERVER_TRAFFIC_PORT_TWO=${SERVER_TRAFFIC_PORT_TWO:-01.01.06}
SERVER_PORT_ONE=${SERVER_PORT_ONE:-01.01.07}
SERVER_PORT_TWO=${SERVER_PORT_TWO:-01.01.08}
CLIENT_PORT_ONE=${CLIENT_PORT_ONE:-01.01.45}
CLIENT_PORT_TWO=${CLIENT_PORT_TWO:-01.01.46}
SWITCH_TRAFFIC_PORT_1=${SWITCH_TRAFFIC_PORT_1:-5010_Eth1_3}
SWITCH_TRAFFIC_PORT_2=${SWITCH_TRAFFIC_PORT_2:-5010_Eth1_4}
SWITCH_TRAFFIC_PORT_3=${SWITCH_TRAFFIC_PORT_3:-5010_Eth1_5}
SWITCH_TRAFFIC_PORT_4=${SWITCH_TRAFFIC_PORT_4:-5010_Eth1_6}
########################################################################################


#OVS DPDK BONDING SWITCH INFO CONFIG
SWITCH_NAME=${SWITCH_NAME:-5010}
SERVER_SWPORT=${SERVER_SWPORT:-Eth1/4 Eth1/3}
CLIENT_SWPORT=${CLIENT_SWPORT:-Eth1/5 Eth1/6}
SERVER_SWPORT_ONE=`echo $SERVER_SWPORT| awk '{print $1}'`
SERVER_SWPORT_TWO=`echo $SERVER_SWPORT| awk '{print $2}'`
CLIENT_SWPORT_ONE=`echo $CLIENT_SWPORT| awk '{print $1}'`
CLIENT_SWPORT_TWO=`echo $CLIENT_SWPORT| awk '{print $2}'`


#CLIENT AND SERVER HOST NIC CONFIG
NIC_DRIVER=${NIC_DRIVER:-ixgbe}
CLIENT_NIC1_NAME="p7p1"
CLIENT_NIC2_NAME="p7p2"
SERVER_NIC1_XENA="p7p1"
SERVER_NIC2_XENA="p7p2"
SERVER_NIC1_NAME="p6p2"
SERVER_NIC2_NAME="p6p1"


#OPENVSWITCH AND DPDK CONFIG 
OVS_SELINUX_URL=${OVS_SELINUX_URL:-http://download-node-02.eng.bos.redhat.com/brewroot/packages/openvswitch-selinux-extra-policy/1.0/3.el7fdp/noarch/openvswitch-selinux-extra-policy-1.0-3.el7fdp.noarch.rpm}
OVS_URL=${OVS_URL:-http://download-node-02.eng.bos.redhat.com/brewroot/packages/openvswitch/2.9.0/36.el7fdp/x86_64/openvswitch-2.9.0-36.el7fdp.x86_64.rpm}
DPDK_URL=${DPDK_URL:-http://download.eng.pek2.redhat.com/brewroot/packages/dpdk/17.11/7.el7/x86_64/dpdk-17.11-7.el7.x86_64.rpm}
DPDK_TOOL_URL=${DPDK_TOOL_URL:-http://download.eng.pek2.redhat.com/brewroot/packages/dpdk/17.11/7.el7/x86_64/dpdk-tools-17.11-7.el7.x86_64.rpm}


#OVS DPDK BONDING GUEST CONFIG
GUEST_DPDK_VERSION=${GUEST_DPDK_VERSION:-1711}
GUEST_IMG=${GUEST_IMG:-"7.5"}
GUEST_TESTPMD_Q_NUM=${GUEST_TESTPMD_Q_NUM:-1}


# VM image OVS DPDK BONDING TEST 
IMG_GUEST=${IMG_GUEST:-"http://people.redhat.com/ctrautma/RHEL7-5VNF-1Q.qcow2.lrz"}


#CONFIG END , DO NOT EDIT THE FOLLOW CODE UNLESS YOU SURE YOU CAN !!!
##################################################################################################
#############################################################################################
# NO NEED TO CHANGE BELOW THIS LINE
#
# Run test automatically from here
#

source $CASE_PATH/lib/lib_nc_sync.sh
source $CASE_PATH/lib/lib_netperf_all.sh
source $CASE_PATH/lib/lib_swcfg.sh
source $CASE_PATH/lib/lib_utils.sh
export PATH=$PATH:$CASE_PATH/bin/

time_stamp=$(date +%Y-%m-%d-%T)
NIC_LOG_FOLDER="/root/rhel_nft_logs/${time_stamp}"
mkdir -p $NIC_LOG_FOLDER
echo "NIC_LOG_FOLDER_KERNEL=${NIC_LOG_FOLDER}" > $NIC_LOG_FOLDER/kernel_functional_logs.txt

if hostname | grep $CLIENTS &>/dev/null
then
    test_log=${NIC_LOG_FOLDER}/client.log
else
    test_log=${NIC_LOG_FOLDER}/server.log
fi

echo CUSTOMER_PFT=${CUSTOMER_PFT} | tee -a ${test_log}

echo TREX_NIC_NAME_ONE=$TREX_NIC_NAME_ONE | tee -a ${test_log}
echo TREX_NIC_NAME_TWO=$TREX_NIC_NAME_TWO | tee -a ${test_log}

echo CONN_TYPE=${CONN_TYPE} | tee -a ${test_log}
echo TRAFFIC_TYPE=${TRAFFIC_TYPE} | tee -a ${test_log}
echo THROUGH_PUT_TRAFFIC_TYPE=${TRAFFIC_TYPE} | tee -a ${test_log}

echo CLIENTS=$CLIENTS | tee -a ${test_log}
echo SERVERS=$SERVERS | tee -a ${test_log}

echo TREX_SERVER_IP=${TREX_SERVER_IP} | tee -a ${test_log}
echo TREX_SERVER_PASSWORD=${TREX_SERVER_PASSWORD} | tee -a ${test_log}

echo TRAFFIC_PORT_ONE=${TRAFFIC_PORT_ONE} | tee -a ${test_log}
echo TRAFFIC_PORT_TWO=${TRAFFIC_PORT_TWO} | tee -a ${test_log}
echo SERVER_TRAFFIC_PORT_ONE=${SERVER_TRAFFIC_PORT_ONE} | tee -a ${test_log}
echo SERVER_TRAFFIC_PORT_TWO=${SERVER_TRAFFIC_PORT_TWO} | tee -a ${test_log}
echo SERVER_PORT_ONE=${SERVER_PORT_ONE} | tee -a ${test_log}
echo SERVER_PORT_TWO=${SERVER_PORT_TWO} | tee -a ${test_log}
echo CLIENT_PORT_ONE=${CLIENT_PORT_ONE} | tee -a ${test_log}
echo CLIENT_PORT_TWO=${CLIENT_PORT_TWO} | tee -a ${test_log}
echo SWITCH_TRAFFIC_PORT_1=${SWITCH_TRAFFIC_PORT_1} | tee -a ${test_log}
echo SWITCH_TRAFFIC_PORT_2=${SWITCH_TRAFFIC_PORT_2} | tee -a ${test_log}
echo SWITCH_TRAFFIC_PORT_3=${SWITCH_TRAFFIC_PORT_3} | tee -a ${test_log}
echo SWITCH_TRAFFIC_PORT_4=${SWITCH_TRAFFIC_PORT_4} | tee -a ${test_log}


echo SWITCH_NAME=${SWITCH_NAME} | tee -a ${test_log}
echo SERVER_SWPORT=${SERVER_SWPORT} | tee -a ${test_log}
echo CLIENT_SWPORT=${CLIENT_SWPORT} | tee -a ${test_log}
echo SERVER_SWPORT_ONE=${SERVER_SWPORT_ONE} | tee -a ${test_log}
echo SERVER_SWPORT_TWO=${SERVER_SWPORT_TWO} | tee -a ${test_log}
echo CLIENT_SWPORT_ONE=${CLIENT_SWPORT_ONE} | tee -a ${test_log}
echo CLIENT_SWPORT_TWO=${CLIENT_SWPORT_TWO} | tee -a ${test_log}


echo NIC_DRIVER=${NIC_DRIVER} | tee -a ${test_log}
echo CLIENT_NIC1_NAME=${CLIENT_NIC1_NAME} | tee -a ${test_log}
echo CLIENT_NIC2_NAME=${CLIENT_NIC2_NAME} | tee -a ${test_log}
echo SERVER_NIC1_XENA=${SERVER_NIC1_XENA} | tee -a ${test_log}
echo SERVER_NIC2_XENA=${SERVER_NIC2_XENA} | tee -a ${test_log}
echo SERVER_NIC1_NAME=${SERVER_NIC1_NAME} | tee -a ${test_log}
echo SERVER_NIC2_NAME=${SERVER_NIC2_NAME} | tee -a ${test_log}


echo OVS_SELINUX_URL=${OVS_SELINUX_URL} | tee -a ${test_log}
echo OVS_URL=${OVS_URL} | tee -a ${test_log}
echo DPDK_URL=${DPDK_URL} | tee -a ${test_log}
echo DPDK_TOOL_URL=${DPDK_TOOL_URL} | tee -a ${test_log}

echo GUEST_DPDK_VERSION=${GUEST_DPDK_VERSION} | tee -a ${test_log}
echo GUEST_IMG=${GUEST_IMG} | tee -a ${test_log}
echo GUEST_TESTPMD_Q_NUM=${GUEST_TESTPMD_Q_NUM} | tee -a ${test_log}

echo IMG_GUEST=${IMG_GUEST} | tee -a ${test_log}

#run the test scripts
pushd ovs-dpdk-bonding > /dev/null
unset CASE_PATH
CASE_PATH=`pwd`
. runtest.sh |& tee -a ${test_log}
popd
