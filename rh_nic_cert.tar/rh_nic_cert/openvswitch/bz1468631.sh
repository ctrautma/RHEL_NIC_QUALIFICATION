#!/bin/bash
# vim: dict=/usr/share/beakerlib/dictionary.vim cpt=.,w,b,u,t,i,k sts=4 sw=4 et
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   runtest.sh of /kernel/networking/openvswitch/bz_regression/bz1468631
#   Author: Christian Trautman <ctrautma@redhat.com>
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2017 Red Hat, Inc.
#
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PACKAGE="kernel"

source env.sh

if [[ -z $PMD2MASK ]]
then
    # does not appear to be running from beaker as PMD2MASK in yaml not set, try reading in the partner qual script
    # conf file
    set -o allexport
    source /root/NicQual/Perf-Verify.conf
    set +o allexport

    NIC1_PCI_ADDR=`ethtool -i $NIC1 | awk /bus-info/ | awk {'print $2'}`
    echo "$NIC1 address is $NIC1_PCI_ADDR"
fi

install_rpms()
{
    if ! [[ `rpm -qa | grep ^openvswitch-[0-9]` ]]
    # assume inside beaker run
    then
        rpm -ivh $openvswitch_rpm
        rpm -ivh $driverctl_rpm
        rpm -ivh $dpdk_rpm
        rpm -ivh $dpdk_rpm_tools
        yum install -y tuned-profiles-cpu-partitioning
    fi
}

install_tools()
{
if ! [ `rpm -qa | grep qemu-kvm-rhev` ]
then
# assume inside beaker run
cat <<EOT >> /etc/yum.repos.d/osp8-rhel.repo
[osp8-rhel7]
name=osp8-rhel7
baseurl=http://download.lab.bos.redhat.com/rel-eng/OpenStack/8.0-RHEL-7/latest/RH7-RHOS-8.0/x86_64/os/
enabled=1
gpgcheck=0
skip_if_unavailable=1
EOT

    yum install -y qemu-kvm-rhev
    yum install -y wget nano ftp yum-utils git tuna openssl
    yum install -y libpcap libvirt sysstat
fi
}

download_vnf_image() {
    pushd /root/
    if ${GUEST_IMG} == '7.4' ];then
        git clone https://github.com/ctrautma/NicQual.git
        yum install -y NicQual/lrzip-0.616-5.el7.x86_64.rpm

        wget -nv -N people.redhat.com/ctrautma/RHEL7-4VNF.qcow2.lrz

        lrzip -d RHEL7-4VNF.qcow2.lrz

        cp /root/RHEL7-4VNF.qcow2 /var/lib/libvirt/images/RHEL.qcow2
    elif [ ${GUEST_IMG} == '7.5' ];then
        wget ${WEB_SERVER}/rhel${guest_version}-vsperf.qcow2
        mv /root/rhel${guest_version}-vsperf.qcow2 /var/lib/libvirt/images/RHEL.qcow2
    fi
    popd
}

color_mod() {
echo -e "LS_COLORS='rs=0:di=01;32:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arc=01;31:*.arj=01;31:*.taz=01;31:*.lha=01;31:*.lz4=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.tzo=01;31:*.t7z=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.dz=01;31:*.gz=01;31:*.lrz=01;31:*.lz=01;31:*.lzo=01;31:*.xz=01;31:*.bz2=01;31:*.bz=01;31:*.tbz=01;31:*.tbz2=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.war=01;31:*.ear=01;31:*.sar=01;31:*.rar=01;31:*.alz=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.cab=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.webm=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.axv=01;35:*.anx=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=00;36:*.au=00;36:*.flac=00;36:*.mid=00;36:*.midi=00;36:*.mka=00;36:*.mp3=00;36:*.mpc=00;36:*.ogg=00;36:*.ra=00;36:*.wav=00;36:*.axa=00;36:*.oga=00;36:*.spx=00;36:*.xspf=00;36:';" >> ~/.bashrc
echo -e "export LS_COLORS" >> ~/.bashrc
}

define_vm() {

sleep 60 #DBUS error message

touch /root/guest30032.xml
cat <<EOT > /root/guest30032.xml
<domain type='kvm'>
  <name>guest30032</name>
  <uuid>37425e76-af6a-44a6-aba0-73434afe34c0</uuid>
  <memory unit='KiB'>4194304</memory>
  <currentMemory unit='KiB'>4194304</currentMemory>
  <memoryBacking>
    <hugepages>
      <page size='1048576' unit='KiB' nodeset='0'/>
    </hugepages>
    <locked/>
  </memoryBacking>
  <vcpu placement='static'>2</vcpu>
  <cputune>
    <vcpupin vcpu='0' cpuset='$VCPU1'/>
    <vcpupin vcpu='1' cpuset='$VCPU2'/>
    <emulatorpin cpuset='$VCPU1'/>
  </cputune>
  <numatune>
    <memory mode='strict' nodeset='0'/>
  </numatune>
  <resource>
    <partition>/machine</partition>
  </resource>
  <os>
    <type arch='x86_64' machine='pc-i440fx-rhel7.2.0'>hvm</type>
    <boot dev='hd'/>
  </os>
  <features>
    <acpi/>
    <apic/>
  </features>
  <cpu mode='custom' match='exact'>
    <numa>
      <cell id='0' cpus='0-1' memory='4194304' unit='KiB' memAccess='shared'/>
    </numa>
  </cpu>
  <clock offset='utc'>
    <timer name='rtc' tickpolicy='catchup'/>
    <timer name='pit' tickpolicy='delay'/>
    <timer name='hpet' present='no'/>
  </clock>
  <on_poweroff>destroy</on_poweroff>
  <on_reboot>restart</on_reboot>
  <on_crash>restart</on_crash>
  <pm>
    <suspend-to-mem enabled='no'/>
    <suspend-to-disk enabled='no'/>
  </pm>
  <devices>
    <emulator>/usr/libexec/qemu-kvm</emulator>
    <disk type='file' device='disk'>
      <driver name='qemu' type='qcow2'/>
      <source file='/var/lib/libvirt/images/RHEL7.qcow2'/>
      <target dev='vda' bus='virtio'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x06' function='0x0'/>
    </disk>
    <controller type='usb' index='0' model='ich9-ehci1'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x7'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci1'>
      <master startport='0'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x0' multifunction='on'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci2'>
      <master startport='2'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x1'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci3'>
      <master startport='4'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x2'/>
    </controller>
    <controller type='pci' index='0' model='pci-root'/>
    <controller type='virtio-serial' index='0'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x0'/>
    </controller>
    <interface type='vhostuser'>
      <mac address='52:54:00:11:8f:ea'/>
      <source type='unix' path='/var/run/openvswitch/vhost0' mode='client'/>
      <model type='virtio'/>
      <driver name='vhost' queues='2'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x08' function='0x0'/>
    </interface>
    <serial type='pty'>
      <target port='0'/>
    </serial>
    <console type='pty'>
      <target type='serial' port='0'/>
    </console>
    <channel type='unix'>
      <target type='virtio' name='org.qemu.guest_agent.0'/>
      <address type='virtio-serial' controller='0' bus='0' port='1'/>
    </channel>
    <input type='tablet' bus='usb'>
      <address type='usb' bus='0' port='1'/>
    </input>
    <input type='mouse' bus='ps2'/>
    <input type='keyboard' bus='ps2'/>
    <graphics type='vnc' port='-1' autoport='yes' listen='0.0.0.0'>
      <listen type='address' address='0.0.0.0'/>
    </graphics>
    <video>
      <model type='cirrus' vram='16384' heads='1' primary='yes'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x02' function='0x0'/>
    </video>
    <memballoon model='virtio'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x07' function='0x0'/>
    </memballoon>
  </devices>
  <seclabel type='dynamic' model='selinux' relabel='yes'/>
</domain>
EOT

virsh list --all | grep guest30032 && virsh destroy guest30032
virsh net-list | grep default && { virsh net-destroy default; virsh net-undefine default; }
sleep 2
virsh net-define /usr/share/libvirt/networks/default.xml
virsh net-start default
virsh define /root/guest30032.xml
}


setup_dpdk() {

    cat /proc/cmdline
    cat /proc/meminfo
    modprobe vfio-pci
    modprobe vfio

    dpdk-devbind -b vfio-pci $NIC1_PCI_ADDR
    sleep 3

    modprobe openvswitch
    systemctl stop openvswitch
    sleep 3
    systemctl start openvswitch
    sleep 3

    ovs-vsctl --if-exists del-br ovsbr0
    sleep 5

    ovs-vsctl --if-exists del-br ovsbr0
    ovs-vsctl set Open_vSwitch . other_config={}
    ovs-vsctl add-br ovsbr0 -- set bridge ovsbr0 datapath_type=netdev
    ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-init=true
    ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-socket-mem="1024,1024"
    ovs-vsctl set Open_vSwitch . other_config:pmd-cpu-mask=$PMD2MASK
    systemctl restart openvswitch
    sleep 20

    if [ `rpm -qa | grep openvswitch | grep 2.6` ]
    then
        ovs-vsctl add-port ovsbr0 dpdk0 -- set interface dpdk0 type=dpdk ofport_request=10
    else
        ovs-vsctl add-port ovsbr0 dpdk0 -- set interface dpdk0 type=dpdk ofport_request=10 options:dpdk-devargs=$NIC1_PCI_ADDR
    fi
    ovs-vsctl add-port ovsbr0 vhost0 -- set interface vhost0 type=dpdkvhostuser ofport_request=20
    cat /var/log/openvswitch/ovs-vswitchd.log
}

run_test() {
    local result=0

    if i_am_server
    then
        ip link set $NIC1 up
        ip add add 192.168.10.2/24 dev $NIC1
        ping -i0 192.168.10.1 &

        sync_set client test_start
        sync_wait client test_end

        pkill ping
        ip add flush $NIC1
    else
        sync_wait server test_start

        local result=0

        for ((i=0; i<10; i++))
        {
            chmod 777 /var/run/openvswitch/vhost0

            virsh start guest30032
            sleep 90 # wait VM boot up

            # set IP address of the port in VM
            vmsh run_cmd guest30032 "ip add add 192.168.10.1/24 dev eth0"

            # change MTU on host
            ovs-vsctl set int vhost0 mtu_request=1900
            ovs-vsctl set int vhost0 mtu_request=2000
            ovs-vsctl set int vhost0 mtu_request=2200
            ovs-vsctl set int vhost0 mtu_request=2300
            ovs-vsctl set int vhost0 mtu_request=9000
            ovs-vsctl set int vhost0 mtu_request=2000
            ovs-vsctl set int vhost0 mtu_request=1500
            ovs-vsctl set int vhost0 mtu_request=1500

            # fail if found segfault
            cat /var/log/messages | grep segfault && { result=1; break; }

            virsh destroy guest30032
            sleep 10
        }

        sync_set server test_end

        virsh destroy guest30032
        sleep 10
        virsh undefine guest30032
    fi

    return $result
}

config_hugepages() {
    if ! grep "hugepagesz=1G" /etc/default/grub
    # assume inside beaker run
    then
        sed -i 's/\(GRUB_CMDLINE_LINUX.*\)"$/\1/g' /etc/default/grub
        sed -i "s/GRUB_CMDLINE_LINUX.*/& nohz=on default_hugepagesz=1G hugepagesz=1G hugepages=24 intel_iommu=on iommu=pt\"/g" /etc/default/grub
        grub2-mkconfig -o /boot/grub2/grub.cfg
        echo "Manual run system will reboot, please re-run test after reboot"
        rhts-reboot
    fi
}

cleanup() {
    if i_am_client
    then
        ovs-vsctl --if-exists del-br ovsbr0 2>/dev/null
        systemctl stop openvswitch
        sleep 10
        dpdk-devbind -s | grep drv=vfio-pci | awk '{system("driverctl -v unset-override "$1)}'
    fi
}

rlJournalStart

rlPhaseStartSetup
    rlRun "install_tools"
    rlRun "install_rpms"
    rlRun "color_mod"
    if i_am_client
    then
        cleanup
        rlRun "config_hugepages"
        rlRun "download_vnf_image"
        rlRun "define_vm"
        rlRun "setup_dpdk"
    fi
rlPhaseEnd

rlPhaseStartTest "bz1468631"
    rlRun "run_test"
rlPhaseEnd

rlPhaseStartCleanup
    rlRun "cleanup"
rlPhaseEnd

rlJournalPrintText
rlJournalEnd
