#!/bin/bash
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   runtest.sh of /kernel/networking/openvswitch/bz_regression/bz1468631
#   Author: Christian Trautman <ctrautma@redhat.com>
#   Modifier Hekai Wang <hewang@redhat.com>
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2017 Red Hat, Inc.
#
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
PACKAGE="kernel"

source env.sh

install_rpms()
{

	# rpm -q qemu-kvm-rhev &>/dev/null || cat > /etc/yum.repos.d/rhev-mgmt-agent.repo <<-EOF
	# [rhev-mgmt-agent]
	# name=rhev-mgmt-agent
	# baseurl=http://cdn.stage.redhat.com/content/dist/rhel/server/7/7Server/x86_64/rhev-mgmt-agent/3/os/
	# enabled=1
	# gpgcheck=0
	# skip_if_unavailable=1
	# EOF

	local latest_qemu_rpm='http://download.lab.bos.redhat.com/rcm-guest/puddles/OpenStack/rhos-release/rhos-release-latest.noarch.rpm'
	rpm -q qemu-kvm-rhev &>/dev/null || yum install -y ${latest_qemu_rpm}
	install /var/lib/rhos-release/repos/rhos-release-12.repo /etc/yum.repos.d/

	rpm -q qemu-kvm-rhev 2>/dev/null || yum -y install qemu-kvm-rhev
	libvirtd --version &> /dev/null || yum -y install libvirt
	virt-install --version &> /dev/null || yum -y install virt-install
	systemctl restart libvirtd

	rpm_install()
	{
		if ! rpm -q $(basename -s .rpm $1) &>/dev/null
		then
			[ -e $(basename $1) ] || wget $1
			local pkg=$(rpm -qp --qf "%{NAME}" $(basename $1))
			rpm -q $pkg && yum -y remove $pkg
			yum -y install $(basename $1)
		fi
		rpm -q $(basename -s .rpm $1)
	}
	rpm_install $RPM_OVS
	rpm_install $RPM_DRIVERCTL
	rpm_install $RPM_DPDK
	rpm_install $RPM_DPDK_TOOLS
}

download_vnf_image()
{
    # prepare VM
	pushd "/var/lib/libvirt/images/" 1>/dev/null
	if ! [[ -f $(basename -s .lrz $IMG_GUEST) ]]
	then
		if [[ ! -f $(basename $IMG_GUEST) ]]
		then
			if [[ -f $IMG_GUEST ]]
			then
				cp $IMG_GUEST .
			else
				wget -nv -N $IMG_GUEST
			fi
		fi

		if [[ "${IMG_GUEST##*.}" = "lrz" ]]
		then
			rpm -q epel-release-7 &>/dev/null || yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
			lrzip -V 2>/dev/null || yum -y install lrzip
			lrzip -d "$(basename $IMG_GUEST)"
		fi
	fi
	cp --remove-destination $(basename -s .lrz $IMG_GUEST) g1.qcow2
	popd 1>/dev/null
}

create_vm_xml()
{
	cat > g1.xml <<-EOT
	<domain type='kvm'>
	  <name>g1</name>
	  <memory unit='KiB'>4194304</memory>
	  <currentMemory unit='KiB'>4194304</currentMemory>
	  <memoryBacking>
		<hugepages>
		  <page size='1048576' unit='KiB' nodeset='0'/>
		</hugepages>
	    <access mode="shared"/>
	  </memoryBacking>
	  <vcpu placement='static'>3</vcpu>
	  <resource>
		<partition>/machine</partition>
	  </resource>
	  <os>
		<type arch='x86_64'>hvm</type>
		<boot dev='hd'/>
	  </os>
	  <features>
		<acpi/>
		<apic/>
	  </features>
	  <cpu mode='custom' match='exact'>
		<numa>
		  <cell id='0' cpus='0-1' memory='4194304' unit='KiB' memAccess='shared'/>
		</numa>
	  </cpu>
	  <clock offset='utc'>
		<timer name='rtc' tickpolicy='catchup'/>
		<timer name='pit' tickpolicy='delay'/>
		<timer name='hpet' present='no'/>
	  </clock>
	  <on_poweroff>destroy</on_poweroff>
	  <on_reboot>restart</on_reboot>
	  <on_crash>restart</on_crash>
	  <pm>
		<suspend-to-mem enabled='no'/>
		<suspend-to-disk enabled='no'/>
	  </pm>
	  <devices>
		<emulator>/usr/libexec/qemu-kvm</emulator>
		<disk type='file' device='disk'>
		  <driver name='qemu' type='qcow2'/>
		  <source file='/var/lib/libvirt/images/g1.qcow2'/>
		  <target dev='vda' bus='virtio'/>
		  <address type='pci' domain='0x0000' bus='0x00' slot='0x06' function='0x0'/>
		</disk>
		<controller type='pci' index='0' model='pci-root'/>
		<controller type='virtio-serial' index='0'>
		  <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x0'/>
		</controller>
		<interface type='vhostuser'>
		  <mac address='00:de:ad:01:02:03'/>
		  <source type='unix' path='/var/run/openvswitch/vhost0' mode='server'/>
		  <model type='virtio'/>
		  <driver name='vhost' queues='2'/>
		  <address type='pci' domain='0x0000' bus='0x00' slot='0x08' function='0x0'/>
		</interface>
		<serial type='pty'>
		  <target port='0'/>
		</serial>
		<console type='pty'>
		  <target type='serial' port='0'/>
		</console>
		<channel type='unix'>
		  <target type='virtio' name='org.qemu.guest_agent.0'/>
		  <address type='virtio-serial' controller='0' bus='0' port='1'/>
		</channel>
	  </devices>
	</domain>
	EOT

	virsh list --name | grep g1 &>/dev/null && { virsh destroy g1 2>/dev/null; sleep 5; virsh undefine g1 2>/dev/null; }
	sleep 10

	return 0
}


setup_dpdk()
{
	# log the info
	cat /proc/cmdline
	cat /proc/meminfo

	modprobe vfio-pci
	modprobe vfio
	dpdk-devbind -s 2>/dev/null | grep $nic_driver | awk '{system("driverctl -v set-override "$1" vfio-pci")}'

	systemctl status openvswitch &>/dev/null || systemctl start openvswitch
	ovs-vsctl --if-exists del-br ovsbr0 &>/dev/null
	ovs-vsctl set Open_vSwitch . other_config={}
	ovs-vsctl add-br ovsbr0 -- set bridge ovsbr0 datapath_type=netdev
	ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-init=true
	ovs-vsctl --no-wait set Open_vSwitch . other_config:dpdk-socket-mem="1024,1024"
	#ovs-vsctl set Open_vSwitch . other_config:pmd-cpu-mask=$PMD2MASK
	systemctl restart openvswitch
	sleep 10

	if [ `rpm -qa | grep openvswitch | grep 2.6` ]
	then
		ovs-vsctl add-port ovsbr0 dpdk0 \
			-- set interface dpdk0 type=dpdk ofport_request=10
	else
		ovs-vsctl add-port ovsbr0 dpdk0 \
			-- set interface dpdk0 type=dpdk ofport_request=10 options:dpdk-devargs=$nic_pci_addr
	fi
	ovs-vsctl add-port ovsbr0 vhost0 \
		-- set interface vhost0 type=dpdkvhostuserclient ofport_request=20 options:vhost-server-path=/var/run/openvswitch/vhost0

	# log the info
	cat /var/log/openvswitch/ovs-vswitchd.log
	ovs-vsctl show
	ovs-vsctl get Open_vSwitch . other_config

	chmod 777 /var/run/openvswitch/
	echo -e "group = 'hugetlbfs'" >> /etc/libvirt/qemu.conf
	systemctl restart libvirtd
}

run_test() {
	local result=0

	if i_am_server
	then
		ip link set ${nic_test} up
		ip add add 192.168.10.2/24 dev ${nic_test}
		ping -i0 192.168.10.1 &

		sync_set client test_start
		sync_wait client test_end

		pkill ping
		ip add flush ${nic_test}
	else
		sync_wait server test_start

		virsh define g1.xml
		virsh list --all

		dmesg -C

		for ((i=0; i<10; i++))
		do
			virsh start g1
			sleep 90 # wait VM boot up

			# set IP address of the port in VM
			vmsh run_cmd g1 "ip add add 192.168.10.1/24 dev eth0"

			# change MTU on host
			for mtu in 1900 2000 2200 2300 9000 2000 1500 1500
			do
				ovs-vsctl --timeout 10 set int vhost0 mtu_request=$mtu
				dmesg | grep segfault && { result=1; break; }
			done

			((result == 1)) && break;

			virsh destroy g1
			sleep 10
		done

		sync_set server test_end
	fi

	return $result
}

config_hugepages()
{
	local changed=0

	if [[ "$nic_driver" = "qede" ]]
	then
		grep -v qedr /proc/cmdline || grep -v qedr /proc/cmdline || grep -v qedr /proc/cmdline && {
			sed -i -e 's/GRUB_CMDLINE_LINUX="/GRUB_CMDLINE_LINUX="modprobe.blacklist=qedr modprobe.blacklist=qedf modprobe.blacklist=qedi /'  /etc/default/grub
			changed=1
		}
	fi

    if grep -v "intel_iommu=on" /proc/cmdline > /dev/null ||
        grep -v "iommu=pt" /proc/cmdline > /dev/null ||
        grep -v "default_hugepagesz=1G" /proc/cmdline > /dev/null ||
        grep -v "hugepagesz=1G" /proc/cmdline > /dev/null ||
        grep -v "hugepages=[[:digit:]]\+" /proc/cmdline > /dev/null
    then
        sed -i 's/\(GRUB_CMDLINE_LINUX=\)"\(.*\)"/\1"intel_iommu=on iommu=pt default_hugepagesz=1GB hugepagesz=1G hugepages=16 \2"/' /etc/default/grub
		changed=1
    fi
	((changed != 0)) && {
        grub2-mkconfig -o /boot/grub2/grub.cfg
		echo "BOOT OPTIONS ARE CHANGED. REBOOT IS NEEDED. PLEASE RE-RUN THE TEST AFTER RESTART."
        [ -n "$RESULT_SERVER" ] && rhts-reboot || { reboot; exit; }
	}

	return 0
}

cleanup()
{
	virsh list --all 2>/dev/null | sed -n 3~1p | awk '/[[:alpha:]]+/ {
		if ($3 == "running") {
		    system("virsh destroy "$2" &>/dev/null")
		    sleep 2;
		};
		system("virsh undefine --managed-save --snapshots-metadata --remove-all-storage "$2" &>/dev/null")
	}'

	ovs-vsctl --if-exists del-br ovsbr0 &>/dev/null
	systemctl stop openvswitch &>/dev/null
	dpdk-devbind -s 2>/dev/null | grep drv=vfio-pci | awk '{system("driverctl -v unset-override "$1)}' &>/dev/null
	sleep 5

	return 0
}

# main

cleanup

nic_test=${nic_test:-$(get_required_iface)}
nic_driver=`ethtool -i ${nic_test} | awk  '/driver/ {print $2}'`
nic_pci_addr=`ethtool -i ${nic_test} | awk '/bus-info/ {print $2}'`
echo nic_test=$nic_test
echo nic_driver=$nic_driver
echo nic_pci_addr=$nic_pci_addr

rlJournalStart

rlPhaseStartSetup
if i_am_client
then
	rlRun "install_rpms"
	rlRun "config_hugepages"
	rlRun "download_vnf_image"
	rlRun "create_vm_xml"
	rlRun "setup_dpdk"
else
	:
fi
rlPhaseEnd

rlPhaseStartTest "bz1468631"
	rlRun "run_test"
rlPhaseEnd

rlPhaseStartCleanup
	rlRun "cleanup"
rlPhaseEnd

rlJournalPrintText
rlJournalEnd
