#!/bin/bash
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   runtest.sh of /kernel/networking/openvswitch/topo
#   Author: Qijun Ding <qding@redhat.com>
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#   Copyright (c) 2013 Red Hat, Inc.
#
#   This copyrighted material is made available to anyone wishing
#   to use, modify, copy, or redistribute it subject to the terms
#   and conditions of the GNU General Public License version 2.
#
#   This program is distributed in the hope that it will be
#   useful, but WITHOUT ANY WARRANTY; without even the implied
#   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
#   PURPOSE. See the GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public
#   License along with this program; if not, write to the Free
#   Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
#   Boston, MA 02110-1301, USA.
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
dbg_flag=${dbg_flag=:-"set +x"}
$dbg_flag

source env.sh

#----------------------------------------------------------

# this will be called before and after the test
cleanup_env()
{

	# echo "remove any bridge if exist"
	brctl show | sed -n 2~1p | awk '/^[[:alpha:]]/ {
		system("ip link set "$1" down")
		sleep 2
		system("brctl delbr "$1)
	}'

	# echo "remove any vxlan if exist"
	ip -d link show | grep "\bvxlan\b" -B 2 | sed -n 1~3p | awk '{
		gsub(":","")
		system ("ip link del "$2)
	}'

	# echo "remove any gre if exist"
	ip -d link show | grep "\bgretap\b\|\bip6gretap\b" -B 2 | \
		sed -n 1~3p | awk '($2 ~ /[[:alnum:]]+@[[:alnum:]]+/) {
		split($2,gre,"@")
		system("ip link del "gre[1])
	}'

	# echo "remove any VM if exist"
	virsh list --all | sed -n 3~1p | awk '/[[:alpha:]]+/ {
		if ($3 == "running") {
			system("virsh shutdown "$2)
			sleep 2
			system("virsh destroy "$2)
		}
		system("virsh undefine --managed-save --snapshots-metadata --remove-all-storage "$2" &>/dev/null")
	}'
	# echo "remove any vnet definition if exist"
	virsh net-list --all | sed -n 3~1p | awk '/[[:alnum:]]+/ {
		system("virsh net-destroy "$1)
		sleep 2
		system("virsh net-undefine "$1)
	}'

	#echo "remove any netns if exist"
	ip netns list | awk '{ system("ip netns del "$1) }'

	ovs-vsctl list bridge 2>/dev/null | grep name | awk '{
		system("ovs-vsctl --if-exist del-br "$3" &>/dev/null")
	}'
	systemctl stop ovn-controller &>/dev/null
	systemctl stop ovn-northd &>/dev/null
	systemctl stop openvswitch &>/dev/null
	sleep 5
	rm -rf /etc/openvswitch/*.db
	rm -rf /var/lib/openvswitch/*
	sync

}

# set up env for ovs tests
setup_env()
{
	if (($rhel_version >= 7)); then
		sed -i 's/BOOTPROTO=.*$/BOOTPROTO=none/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
		sed -i 's/NM_CONTROLLED=.*$/NM_CONTROLLED=no/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
		sed -i 's/IPV6_AUTOCONF=.*$/IPV6_AUTOCONF=no/g' /etc/sysconfig/network-scripts/ifcfg-${nic_test}
	fi
	iptables -F
	ip6tables -F

	ip link set $nic_test down
	sleep 10
	ip link set $nic_test up

	ip addr flush dev $nic_test
	brctl show

	if (($rhel_version <= 6)); then
		service openvswitch restart
	else
		systemctl restart openvswitch
	fi
	sleep 10

	# prepare openvswitch
	ovs-vsctl add-br $ovs_br
	ip link set $ovs_br up
	ovs-vsctl show

	# prepare VM
	pushd "/var/lib/libvirt/images/" 1>/dev/null
	if ! [[ -f $(basename -s .lrz $IMG_GUEST) ]]
	then
		[[ -f $(basename $IMG_GUEST) ]] || wget -nv -N $IMG_GUEST
		if [[ "${IMG_GUEST##*.}" = "lrz" ]]
			then
			rpm -q epel-release-7 || yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
			lrzip -V 2>/dev/null || yum -y install lrzip
			lrzip -d "$(basename $IMG_GUEST)"
		fi
	fi
	cp --remove-destination $(basename -s .lrz $IMG_GUEST) g1.qcow2
	cp --remove-destination $(basename -s .lrz $IMG_GUEST) g2.qcow2
	popd 1>/dev/null

	# define default vnet
	virsh net-define /usr/share/libvirt/networks/default.xml
	i=30
	while [ $i -ge 0 ] 
        do
		virsh net-start default
		if [ $? != 0 ];then
			sleep 20
		else
			break
		fi
		i=`expr $i - 1`
    done
	virsh net-autostart default

	cat <<-EOF > ovs_vnet_g1.xml
		<network>
		<name>vnet_g1</name>
		<forward mode='bridge'/>
		<bridge name='ovsbr0' />
		<virtualport type='openvswitch'>
		</virtualport>
		</network>
	EOF
	virsh net-define ovs_vnet_g1.xml
	virsh net-start vnet_g1
	virsh net-autostart vnet_g1
	virt-install \
		--name g1 \
		--vcpus=2 \
		--ram=2048 \
		--disk path=/var/lib/libvirt/images/g1.qcow2,device=disk,bus=virtio,format=qcow2 \
		--network bridge=virbr0,model=virtio,mac="${mac4vm}:01" \
		--network network=vnet_g1,model=virtio,mac="${mac4vm}:02" \
		--boot hd \
		--accelerate \
		--graphics vnc,listen=0.0.0.0 \
		--force \
		--os-type=linux \
		--noautoconsol

	cat <<-EOF > ovs_vnet_g2.xml
		<network>
		<name>vnet_g2</name>
		<forward mode='bridge'/>
		<bridge name='ovsbr0' />
		<virtualport type='openvswitch'>
		</virtualport>
		</network>
	EOF
	virsh net-define ovs_vnet_g2.xml
	virsh net-start vnet_g2
	virsh net-autostart vnet_g2
	virt-install \
		--name g2 \
		--vcpus=2 \
		--ram=2048 \
		--disk path=/var/lib/libvirt/images/g2.qcow2,device=disk,bus=virtio,format=qcow2 \
		--network bridge=virbr0,model=virtio,mac="${mac4vm}:11" \
		--network network=vnet_g2,model=virtio,mac="${mac4vm}:12" \
		--boot hd \
		--accelerate \
		--graphics vnc,listen=0.0.0.0 \
		--force \
		--os-type=linux \
		--noautoconsol

	# wait VM bootup
	sleep 90
	if [ -n "$RPM_KERNEL" ]
	then
		# update VM kernel to $RPM_KERNEL
		local k="rpm -ivh --nodeps --force $RPM_KERNEL"
		vmsh run_cmd g1 "$k"
		virsh reboot g1
		vmsh run_cmd g2 "$k"
		virsh reboot g2
		sleep 90
	fi

	# ncat
	if (($rhel_version == 6)); then
		vmsh run_cmd g1 "ncat --version &>/dev/null || yum -y install nmap"
		vmsh run_cmd g2 "ncat --version &>/dev/null || yum -y install nmap"
	else
		vmsh run_cmd g1 "ncat --version &>/dev/null || yum -y install nmap-ncat"
		vmsh run_cmd g2 "ncat --version &>/dev/null || yum -y install nmap-ncat"
	fi

	# vm setup
	if (($rhel_version >= 7)); then
		vmsh run_cmd g1 "systemctl stop NetworkManager"
	fi

	local cmd=(
		{iptables -F}
		{ip6tables -F}
		{setenforce 1}
		{ip link set dev \$\(ip link show\|grep -i ${mac4vm}:02 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\) down}
		{ip link set dev \$\(ip link show\|grep -i ${mac4vm}:02 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\) up}
		{ip addr flush dev \$\(ip link show\|grep -i ${mac4vm}:02 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{ip addr add $ipaddr_vm/24 dev \$\(ip link show\|grep -i ${mac4vm}:02 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{ip addr add $ip6addr_vm/64 dev \$\(ip link show\|grep -i ${mac4vm}:02 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{wget -nv -N $SRC_NETPERF}
		{tar xjvf \$\(basename $SRC_NETPERF\)}
		{pushd \$\(tar -jtf \$\(basename $SRC_NETPERF\) \| head -n 1\) \1\>/dev/null}
		{sed -i "/ppc64/i\ppc64le:Linux:*:*)\n\ echo powerpc64le-unknown-linux-gnu\n\ exit ;;" config.guess}
		{./configure}
		{make}
		{make install}
		{popd \1\>/dev/null}
		{pkill netserver\; sleep 2\; netserver}
	)
	vmsh cmd_set g1 "${cmd[*]}"

	# vm setup
	if (($rhel_version >= 7)); then
		vmsh run_cmd g2 "systemctl stop NetworkManager"
	fi
	local cmd=(
		{iptables -F}
		{ip6tables -F}
		{setenforce 1}
		{ip link set dev \$\(ip link show\|grep -i ${mac4vm}:12 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\) down}
		{ip link set dev \$\(ip link show\|grep -i ${mac4vm}:12 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\) up}
		{ip addr flush dev \$\(ip link show\|grep -i ${mac4vm}:12 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{ip addr add $ipaddr_vm2/24 dev \$\(ip link show\|grep -i ${mac4vm}:12 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{ip addr add $ip6addr_vm2/64 dev \$\(ip link show\|grep -i ${mac4vm}:12 -B 1\|awk \'/^[0-9]+/ \{gsub\(\":\",\"\",\$2\)\; print \$2\}\'\)}
		{wget -nv -N $SRC_NETPERF}
		{tar xjvf \$\(basename $SRC_NETPERF\)}
		{pushd \$\(tar -jtf \$\(basename $SRC_NETPERF\) \| head -n 1\) \1\>/dev/null}
		{sed -i "/ppc64/i\ppc64le:Linux:*:*)\n\ echo powerpc64le-unknown-linux-gnu\n\ exit ;;" config.guess}
		{./configure}
		{make}
		{make install}
		{popd \1\>/dev/null}
		{pkill netserver\; sleep 2\; netserver}
	)

	vmsh cmd_set g2 "${cmd[*]}"

	#stop ipv6 ra, prevent change mtu of ipv6	
	echo 0 > /proc/sys/net/ipv6/conf/$nic_test/accept_ra
}

#----------------------------------------------------------
# tests

ovs_test_nic()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test

	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_nic_mtu_change()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		ping $ipaddr_test_peer &
		ip link set mtu 3000 dev $nic_test
		result=$?

		sync_set server test_end
		ip link set mtu $mtu dev $nic_test
		pkill -9 ping
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

# vlan-subif --- ovsbr0 ------ ovsbr0 --- vlan-subif
ovs_test_vlan()
{
	local mtu=${1:-1500}
	local vid=3
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link add link $nic_test name $nic_test.$vid type vlan id $vid
	sleep 1
	ip link set mtu $mtu dev $nic_test.$vid
	ip link set $nic_test.$vid up
	ovs-vsctl add-port $ovs_br $nic_test.$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $nic_test.$vid
	ip -d link show $ovs_br
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $nic_test.$vid
	ip link set $nic_test.$vid down
	ip link del $nic_test.$vid
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan1()
{
	local mtu=${1:-1500}
	local vid=3
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	sleep 1
	ip link set mtu $mtu dev vlan$vid
	ip link set vlan$vid up
	ip link set $ovs_br up

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show vlan$vid
	ip -d link show $ovs_br
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan_mtu_check()
{
    	local mtu=9000
   	local vxlan=vxlan0
    	local result=0
	if i_am_client; then

	ip link set mtu $mtu dev $nic_test
    	for ((i=0; i<30; i++))
	do
		  ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		  sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group 239.3.2.$ipaddr local $ipaddr_nic dev $nic_test
	ip link set $vxlan up
        local vxlan_mtu=$(ifconfig|grep $vxlan|awk '{print $NF}')
        if (($vxlan_mtu!=8950)); then
                result=1
        fi
	    ip -d link show $nic_test
	    ip -d link show $vxlan
	    ip addr show $nic_test

	    ip link set $vxlan down
	    ip link del $vxlan
	    ip addr del $ipaddr_nic/24 dev $nic_test
	    ip link set mtu 1500 dev $nic_test
	fi

	return $result
}

ovs_test_vxlan()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group 239.3.2.$ipaddr local $ipaddr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vxlan_gpe()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr external gpe remote $ipaddr_nic_peer
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan1()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ipaddr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan1_gpe()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:exts=gpe options:remote_ip=$ipaddr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan_flow()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test

	ip link set mtu $(($mtu-50)) dev $ovs_br

	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=flow options:remote_ip=flow ofport_request=10
	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br "in_port=local actions=set_field:5->tun_id,set_field:$ipaddr_nic_peer->tun_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan_flow_set_tunnle()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test

	ip link set mtu $(($mtu-50)) dev $ovs_br

	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=flow options:remote_ip=flow ofport_request=10
	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br "in_port=local actions=set_tunnel:5,set_field:$ipaddr_nic_peer->tun_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_vxlan()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group 239.3.2.$ipaddr local $ipaddr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_vxlan1()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vlan_vxlan_gpe()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr external gpe remote $ipaddr_nic_peer
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_vxlan1_gpe()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:exts=gpe options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_geneve()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ipaddr_nic_peer
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	sleep 1
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ip link set mtu $(($mtu-50)) dev $tun
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $tun
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_geneve1()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ipaddr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-50)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_geneve()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ipaddr_nic_peer
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid
	ip link set mtu $(($mtu-50-4)) dev $tun
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $tun
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_geneve1()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev vlan$vid

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_geneve_flow()
{
	local mtu=${1:-1500}
	local geneve=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test

	ip link set mtu $(($mtu-50)) dev $ovs_br

	ovs-vsctl add-port $ovs_br $geneve -- set interface $geneve type=geneve options:key=flow options:remote_ip=flow ofport_request=10
	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br "in_port=local actions=set_field:5->tun_id,set_field:$ipaddr_nic_peer->tun_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_gre()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $gre type gretap remote $ipaddr_nic_peer local $ipaddr_nic
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl show
	sleep 1
	ip link set mtu $(($mtu-20-4-14)) dev $ovs_br
	ip link set mtu $(($mtu-20-4-14)) dev $gre

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_gre1()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl show
	ip link set mtu $mtu dev gre_sys 
	ip link set mtu $(($mtu-20-4-14)) dev $ovs_br

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_gre()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $gre type gretap remote $ipaddr_nic_peer local $ipaddr_nic
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	sleep 1
	ip link set vlan$vid up
	ip link set mtu $(($mtu-20-4-14-4)) dev vlan$vid

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_gre1()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $mtu dev gre_sys 
	ip link set mtu $(($mtu-20-4-14-4)) dev vlan$vid

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show vlan$vid
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ipaddr_nic/24 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

# VM
ovs_test_vm_nic()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan()
{
	local mtu=${1:-1500}
	local vid=3
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1

	ip link add link $nic_test name $nic_test.$vid type vlan id $vid
	ip link set $nic_test.$vid up
	sleep 1
	ip link set $nic_test.$vid mtu $mtu
	ovs-vsctl add-port $ovs_br $nic_test.$vid
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $nic_test.$vid
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test.$vid
	ip link set $nic_test.$vid down
	ip link del $nic_test.$vid

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_multiple_vlans()
{
	local mtu=${1:-1500}
	local vid=3
	local result1=0
	local result2=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ip link set mtu $mtu dev $tap2
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g2 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:12 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl add-port $ovs_br $tap1 tag=10
	ovs-vsctl add-port $ovs_br $tap2 tag=20
	ovs-vsctl show

	ip -d link show $nic_test
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	vmsh run_cmd g2 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu for vlan10" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result1=$?
		log_header "$FUNCNAME $mtu for vlan20" $result_file
		do_vm_netperf g2 $ipaddr_vm2_peer $ip6addr_vm2_peer $result_file
		result2=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ovs-vsctl del-port $tap1
	ovs-vsctl del-port $tap2
	ovs-vsctl del-port $ovs_br $nic_test

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g2 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:12 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $tap2
	ip link set mtu 1500 dev $nic_test

	return $(($result1 || $result2))
}

ovs_test_vm_vxlan()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group 239.3.2.$ipaddr local $ipaddr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $vxlan
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan1()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan_flow()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1
	ip addr add $ipaddr_nic/24 dev $nic_test

	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=flow options:remote_ip=flow ofport_request=10
	ovs-vsctl add-port $ovs_br $tap1
	ovs-ofctl del-flows  $ovs_br
	local of_port=$(ovs-ofctl dump-ports-desc $ovs_br | grep $tap1 | sed -r 's/^\s*(.*?)\(.*?\).*/\1/')
	ovs-ofctl add-flow  $ovs_br "in_port=$of_port actions=set_field:5->tun_id,set_field:$ipaddr_nic_peer->tun_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br

	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan_gbp()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=123 options:remote_ip=$ipaddr_nic_peer options:exts=gbp
	ovs-vsctl add-port $ovs_br $tap1

	# port no. in openflow table
	local of_port_tap1=$(ovs-ofctl dump-ports-desc $ovs_br | grep $tap1 | sed -rn "s/^[[:blank:]]+([[:alnum:]]+)\($tap1\).*/\1/p")

	ovs-ofctl del-flows $ovs_br
	ovs-ofctl add-flow $ovs_br "tun_gbp_id=123 actions=normal"
	ovs-ofctl add-flow $ovs_br "in_port=$of_port_tap1 actions=set_field:123->tun_gbp_id,normal"
	ovs-vsctl show
	ovs-ofctl dump-ports-desc $ovs_br
	ovs-ofctl dump-flows $ovs_br

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ovs-ofctl del-flows $ovs_br
	ovs-ofctl add-flow $ovs_br "actions=normal"

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_vxlan()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group 239.3.2.$ipaddr local $ipaddr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-50)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_vxlan1()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_geneve()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ipaddr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-50)) dev $tun
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $tun
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_geneve1()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_geneve_flow()
{
	local mtu=${1:-1500}
	local geneve=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50)) dev $tap1
	ip addr add $ipaddr_nic/24 dev $nic_test

	ovs-vsctl add-port $ovs_br $geneve -- set interface $geneve type=geneve options:key=flow options:remote_ip=flow ofport_request=10
	ovs-vsctl add-port $ovs_br $tap1
	ovs-ofctl del-flows  $ovs_br
	local of_port=$(ovs-ofctl dump-ports-desc $ovs_br | grep $tap1 | sed -r 's/^\s*(.*?)\(.*?\).*/\1/')
	ovs-ofctl add-flow  $ovs_br "in_port=$of_port actions=set_field:5->tun_id,set_field:$ipaddr_nic_peer->tun_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br

	vmsh run_cmd g1 "ip link set mtu $(($mtu-50)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $geneve
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_geneve()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ipaddr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-50-4)) dev $tun
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $tun
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_geneve1()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-50-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-50-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_gre()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-20-4-14)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $gre type gretap remote $ipaddr_nic_peer local $ipaddr_nic
	sleep 1
	ip link set mtu $(($mtu-20-4-14)) dev $gre
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-20-4-14)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $gre
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_gre1()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-20-4-14)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	sleep 1
	ip link set mtu $mtu dev gre_sys 
	vmsh run_cmd g1 "ip link set mtu $(($mtu-20-4-14)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_gre()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-20-4-14-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ip link add $gre type gretap remote $ipaddr_nic_peer local $ipaddr_nic
	sleep 1
	ip link set mtu $(($mtu-20-4-14-4)) dev $gre
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-20-4-14-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $gre
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_gre1()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-20-4-14-4)) dev $tap1

	ip addr add $ipaddr_nic/24 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ipaddr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	sleep 1
	ip link set mtu $mtu dev gre_sys 
	vmsh run_cmd g1 "ip link set mtu $(($mtu-20-4-14-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ipaddr_nic/24 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_bond_active_backup()
{
	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		sync_set client test_start
		sync_wait client test_end

		ip addr flush dev $ovs_br
		ovs-vsctl del-port $ovs_br $nic_test

		return 0
	fi

	# used in 'ovs-vsctl add-bond $ovs_br $if_bond if1 if2 lacp=$lacp bond-mode=$mode
	local lacp="off" # active | passive | off
	local mode="active-backup" # active-backup, balance-tcp, or balance-slb
	local if_bond=bond0

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)
	echo "nic_list=$nic_list"

	for nic in $nic_list
	do
		ip link set $nic up
	done
	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp bond-mode=$mode
	ovs-vsctl show
	ip link set $ovs_br up

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	sleep 35

	sync_wait server test_start

	local result=0
	local nic_active=''
	local nic_tmp=''

	echo "----------------------------------------"
	echo "STEP 1: check default active slave"
	echo "----------------------------------------"
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 2: set down the active port in switch side"
	echo "----------------------------------------"
	nic_tmp=$nic_active
	swcfg_port_down_by_linux_iface $nic_tmp
	sleep 35
	ethtool $nic_active

	echo "----------------------------------------"
	echo "STEP 3: active slave should change to the old backup"
	echo "----------------------------------------"
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 4: set up the backup port in switch side"
	echo "----------------------------------------"
	swcfg_port_up_by_linux_iface $nic_tmp
	sleep 35
	ethtool $nic_backup

	echo "----------------------------------------"
	echo "STEP 5: active/backup port should have no change"
	echo "----------------------------------------"
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 6: set down the active port in switch side"
	echo "----------------------------------------"
	nic_tmp=$nic_active
	swcfg_port_down_by_linux_iface $nic_tmp
	sleep 35
	ethtool $nic_backup

	echo "----------------------------------------"
	echo "STEP 7: active slave should change to new one"
	echo "----------------------------------------"
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 8: set up the backup port in switch side"
	echo "----------------------------------------"
	swcfg_port_up_by_linux_iface $nic_tmp
	sleep 35
	ethtool $nic_backup

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 9: cleanup test"
	echo "----------------------------------------"
	ovs-vsctl del-port $ovs_br $if_bond

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br

	ip link set $nic_test up

	return $result
}

ovs_test_bond_set_active_slave()
{
	local result=0

	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		sync_set client test_start
		sync_wait client test_end

		ip addr flush dev $ovs_br
		ovs-vsctl del-port $ovs_br $nic_test

		return 0
	fi

	# used in 'ovs-vsctl add-bond $ovs_br $if_bond if1 if2 lacp=$lacp bond-mode=$mode
	local lacp="off" # active | passive | off
	local mode="active-backup" # active-backup, balance-tcp, or balance-slb
	local if_bond=bond0

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)
	echo "nic_list=$nic_list"

	for nic in $nic_list
	do
		ip link set $nic up
	done
	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp bond-mode=$mode
	ovs-vsctl show
	ip link set $ovs_br up

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	sleep 35

	sync_wait server test_start

	local nic_active=''
	local nic_backup=''

	echo "----------------------------------------"
	echo "STEP 1: check the default active slave"
	echo "----------------------------------------"
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 2: set backup to active"
	echo "----------------------------------------"
	ovs-appctl bond/set-active-slave $if_bond $nic_backup
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 3: set backup to active"
	echo "----------------------------------------"
	ovs-appctl bond/set-active-slave $if_bond $nic_backup
	ovs-appctl bond/show $if_bond
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	log_header "$FUNCNAME($nic_active)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 4: cleanup test"
	echo "----------------------------------------"
	ovs-vsctl del-port $ovs_br $if_bond

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br
	ip link set $nic_test up

	return $result
}

check_lacp_status()
{
	local if_bond=$1

	local cx=0
	while [[ "$(ovs-appctl bond/show $if_bond | sed -n '/lacp_status/ s/lacp_status: //p')" != "negotiated" ]] && ((cx++<60))
	do
		sleep 5
	done

	ovs-appctl bond/show $if_bond
}

ovs_test_bond_lacp_active()
{
	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		sync_set client test_start
		sync_wait client test_end

		ip addr flush dev $ovs_br
		ovs-vsctl del-port $ovs_br $nic_test

		return 0
	fi

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)
	echo "nic_list=$nic_list"

	for nic in $nic_list
	do
		ip link set $nic up
	done

	echo "----------------------------------------"
	echo "STEP 1: setup bonding on switch, and set lacp mode to passive"
	echo "----------------------------------------"
	swcfg_setup_bonding_by_linux_ifaces "$nic_list" "passive"

	echo "----------------------------------------"
	echo "STEP 2: setup bonding on OVS brdige, and set lacp mode to active"
	echo "----------------------------------------"
	local lacp="active" # active | passive | off
	local if_bond=bond0
	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp
	ip link set $ovs_br up
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	sync_wait server test_start

	local result1=0
	local nic_active=''
	local nic_backup=''

	echo "----------------------------------------"
	echo "STEP 3: check active slave"
	echo "----------------------------------------"
	check_lacp_status $if_bond
	local nic_active1=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active1)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 4: set active down, backup slave changes to active"
	echo "----------------------------------------"
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	ip link set $nic_active down
	check_lacp_status $if_bond
	local nic_active2=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active2)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 5: set backup up, active slave should have no change"
	echo "----------------------------------------"
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	ip link set $nic_backup up
	check_lacp_status $if_bond
	local nic_active3=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active3)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 6: cleanup test"
	echo "----------------------------------------"
	swcfg_cleanup_bonding_by_linux_ifaces "$nic_list"

	ovs-vsctl del-port $ovs_br $if_bond

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br
	ip link set $nic_test up

	return $result
}

ovs_test_bond_lacp_passive()
{
	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		sync_set client test_start
		sync_wait client test_end

		ip addr flush dev $ovs_br
		ovs-vsctl del-port $ovs_br $nic_test

		return 0
	fi

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)
	echo "nic_list=$nic_list"

	for nic in $nic_list
	do
		ip link set $nic up
	done

	echo "----------------------------------------"
	echo "STEP 1: setup bonding on switch and set lacp mode to active"
	echo "----------------------------------------"
	swcfg_setup_bonding_by_linux_ifaces "$nic_list" "active"

	echo "----------------------------------------"
	echo "STEP 2: setup bonding on OVS brdige and set lacp mode to passive"
	echo "----------------------------------------"
	local lacp="passive" # active | passive | off
	local if_bond=bond0
	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp
	ip link set $ovs_br up
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	sync_wait server test_start

	local result=0
	local nic_active=''
	local nic_backup=''

	echo "----------------------------------------"
	echo "STEP 3: check active slave"
	echo "----------------------------------------"
	check_lacp_status $if_bond
	local nic_active1=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active1)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 4: set active down, backup switches to active"
	echo "----------------------------------------"
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	ip link set $nic_active down
	check_lacp_status $if_bond
	local nic_active2=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active2)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 5: set backup up, active slave should have no change"
	echo "----------------------------------------"
	nic_active=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	nic_backup=$(ovs-appctl bond/show bond0 | sed -n 's/^slave \(.*\):.*$/\1/p' | grep -v $nic_active)
	ip link set $nic_backup up
	check_lacp_status $if_bond
	local nic_active3=$(ovs-appctl bond/show bond0 | sed -n "s/^active slave mac:.*(\(.*\))$/\1/p")
	log_header "$FUNCNAME($nic_active3)" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 6: cleanup test"
	echo "----------------------------------------"
	swcfg_cleanup_bonding_by_linux_ifaces "$nic_list"

	ovs-vsctl del-port $ovs_br $if_bond

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br
	ip link set $nic_test up

	return $result
}

# Balances flows among slave based on source MAC address and output VLAN,
# with periodic rebalancing as traffic patterns change.
ovs_test_bond_balance_slb()
{
	ovs-vsctl add-port $ovs_br $tap1 tag=10
	ovs-vsctl add-port $ovs_br $tap2 tag=20

	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test
		ovs-vsctl show

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		sync_set client test_start
		sync_wait client test_end

		ovs-vsctl del-port $ovs_br $nic_test

		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $tap2

		ip addr flush dev $ovs_br

		return 0
	fi

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)

	for nic in $nic_list
	do
		ip link set $nic up
	done

	echo "----------------------------------------"
	echo "STEP 1: setup bonding on OVS bridge"
	echo "----------------------------------------"
	local lacp="off" # active | passive | off
	local mode="balance-slb" # active-backup, balance-tcp, or balance-slb
	local if_bond=bond0

	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp bond-mode=$mode
	ip link set $ovs_br up
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	sleep 35

	sync_wait server test_start

	ovs-appctl bond/show $if_bond

	local result=0

	echo "----------------------------------------"
	echo "STEP 2: check connectivity on ovsbr0 between client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 3: check connectivity between guests g1 on client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME (guest:g1)" $result_file
	do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 3: check connectivity between guests g2 on client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME (guest:g2)" $result_file
	do_vm_netperf g2 $ipaddr_vm2_peer $ip6addr_vm2_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 4: check balances flows among slaves based on source MAC address and output VLAN"
	echo "----------------------------------------"
	# here g1 and g2 have different source mac addresses and different output VLAN
	vmsh run_cmd g1 "ping $ipaddr_vm_peer &"
	vmsh run_cmd g2 "ping $ipaddr_vm2_peer &"

	sleep 2

	local nics=($nic_list)
	local nic1_g1=0
	local nic1_g2=0
	local nic2_g1=0
	local nic2_g2=0

	echo "----------------------------------------"
	echo "STEP 5: tcpdump on slave ${nics[0]}"
	echo "----------------------------------------"
	timeout 10s tcpdump ip src $ipaddr_vm -p -c1 -i ${nics[0]} -Q out && nic1_g1='yes' || nic1_g1='no'
	timeout 10s tcpdump ip src $ipaddr_vm2 -p -c1 -i ${nics[0]} -Q out && nic1_g2='yes' || nic1_g2='no'
	echo "balance on ${nics[0]}: nic1_g1=$nic1_g1, nic1_g2=$nic1_g2"
	[[ "$nic1_g1" = "$nic1_g2" ]] && { ((result += 1)); echo "FAIL: to check balance on ${nics[0]}"; }

	echo "----------------------------------------"
	echo "STEP 6: tcpdump on slave ${nics[1]}"
	echo "----------------------------------------"
	timeout 10s tcpdump ip src $ipaddr_vm -p -c1 -i ${nics[1]} -Q out && nic2_g1='yes' || nic2_g1='no'
	timeout 10s tcpdump ip src $ipaddr_vm2 -p -c1 -i ${nics[1]} -Q out && nic2_g2='yes' || nic2_g2='no'
	echo "balance on ${nics[1]}: nic2_g1=$nic2_g1, nic2_g2=$nic2_g2"
	[[ "$nic2_g1" = "$nic2_g2" ]] && { ((result += 1)); echo "FAIL: to check balance on ${nics[1]}"; }

	[[ "$nic1_g1" = "$nic1_g2" ]] || [[ "$nic2_g1" = "$nic2_g2" ]] && { ((result += 1)); echo "FAIL to check balance"; }

	vmsh run_cmd g1 "pkill ping"
	vmsh run_cmd g2 "pkill ping"

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 7: cleanup test"
	echo "----------------------------------------"
	ovs-vsctl del-port $ovs_br $if_bond

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tap2

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br
	ip link set $nic_test up

	return $result
}

# Balances flows among slaves based on L2, L3, and L4 protocol information
# such as destination MAC address, IP address, and TCP port.
ovs_test_bond_balance_tcp()
{
	local test_port1=56000
	local test_port2=57000


	if i_am_server; then
		ovs-vsctl add-port $ovs_br $nic_test
		ovs-vsctl add-port $ovs_br $tap1
		ovs-vsctl add-port $ovs_br $tap2
		ovs-vsctl show

		#make sure vm virtual port is up
		ip link set $tap1 up
		ip link set $tap2 up

		ip addr add $ipaddr_test/24 dev $ovs_br
		ip addr add $ip6addr_test/64 dev $ovs_br

		#vmsh run_cmd g1 "nohup bash -c 'lsof -i TCP:$test_port1 || ncat -l $test_port1 -k &'"
		#vmsh run_cmd g2 "nohup bash -c 'lsof -i TCP:$test_port2 || ncat -l $test_port2 -k &'"

		vmsh run_cmd g1 "for ((i=0; i<255; i++)) do { ncat -l \$(($test_port1+i)) -k >/dev/null & } done"
		vmsh run_cmd g2 "for ((i=0; i<255; i++)) do { ncat -l \$(($test_port2+i)) -k >/dev/null & } done"

		sync_set client test_start
		sync_wait client test_end

		vmsh run_cmd g1 "pkill ncat"
		vmsh run_cmd g2 "pkill ncat"

		ip addr flush dev $ovs_br
		ovs-vsctl del-port $ovs_br $tap2
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $nic_test

		return 0
	fi

	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl add-port $ovs_br $tap2

	# get the required resource for test
	local nic_list=$(NIC_NUM=2 get_required_iface)
	echo "nic_list=$nic_list"

	for nic in $nic_list
	do
		ip link set $nic up
	done

	echo "----------------------------------------"
	echo "STEP 1: setup bonding on switch and set lacp mode to passive"
	echo "----------------------------------------"
	swcfg_setup_bonding_by_linux_ifaces "$nic_list" "passive"

	echo "----------------------------------------"
	echo "STEP 2: setup bonding on OVS bridge and set lacp mode to active"
	echo "----------------------------------------"
	local lacp="active" # active | passive | off
	local mode="balance-tcp" # active-backup, balance-tcp, or balance-slb
	local if_bond=bond0
	ovs-vsctl add-bond $ovs_br $if_bond $nic_list lacp=$lacp bond-mode=$mode
	ip link set $ovs_br up
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	sync_wait server test_start

	local result=0

	check_lacp_status $if_bond

	echo "----------------------------------------"
	echo "STEP 3: check connectivity on ovsbr0 between client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME" $result_file
	do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 4: check connectivity between guests g1 on client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME (guest:g1)" $result_file
	do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 5: check connectivity between guests g2 on client and server"
	echo "----------------------------------------"
	log_header "$FUNCNAME (guest:g2)" $result_file
	do_vm_netperf g2 $ipaddr_vm2_peer $ip6addr_vm2_peer $result_file || ((result += 1))

	echo "----------------------------------------"
	echo "STEP 6: check balances flows among slaves based on L3 and L4 protocol information such as IP addresses and TCP/UDP ports"
	echo "----------------------------------------"
	# here ncat for g1 and g2 have different src/dst ip addresses, src/dst tcp port
	vmsh run_cmd g1 "for ((i=0; i<255; i++)) do { while true; do echo -n .; sleep 1; done | ncat $ipaddr_vm_peer \$(($test_port1+i)) & } done"
	vmsh run_cmd g2 "for ((i=0; i<255; i++)) do { while true; do echo -n .; sleep 1; done | ncat $ipaddr_vm2_peer \$(($test_port2+i)) & } done"

	local nics=($nic_list)
	local nic1_g1=0
	local nic1_g2=0
	local nic2_g1=0
	local nic2_g2=0

	echo "----------------------------------------"
	echo "STEP 7: check balance on ${nics[0]}"
	echo "----------------------------------------"
	timeout 10s tcpdump ip src $ipaddr_vm -nev -p -c1 -i ${nics[0]} -Q out && nic1_g1='yes' || nic1_g1='no'
	timeout 10s tcpdump ip src $ipaddr_vm2 -nev -p -c1 -i ${nics[0]} -Q out && nic1_g2='yes' || nic1_g2='no'
	echo
	echo "balance on ${nics[0]}: nic1_g1=$nic1_g1, nic1_g2=$nic1_g2"
	[[ "$nic1_g1" != "yes" ]] || [[ "$nic1_g2" != "yes" ]] && { ((result += 1)); echo "FAIL: to check balance on ${nics[0]}"; }

	echo "----------------------------------------"
	echo "STEP 8: check balance on ${nics[1]}"
	echo "----------------------------------------"
	timeout 10s tcpdump ip src $ipaddr_vm -p -c1 -i ${nics[1]} -Q out && nic2_g1='yes' || nic2_g1='no'
	timeout 10s tcpdump ip src $ipaddr_vm2 -p -c1 -i ${nics[1]} -Q out && nic2_g2='yes' || nic2_g2='no'
	echo
	echo "balance on ${nics[1]}: nic1_g1=$nic2_g1, nic1_g2=$nic2_g2"
	[[ "$nic2_g1" != "yes" ]] || [[ "$nic2_g2" != "yes" ]] && { ((result += 1)); echo "FAIL: to check balance on ${nics[1]}"; }

	#[[ "$nic1_g1" = "$nic1_g2" ]] || [[ "$nic2_g1" = "$nic2_g2" ]] && { ((result += 1)); echo "FAIL to check balance"; }

	vmsh run_cmd g1 "pkill ncat"
	vmsh run_cmd g2 "pkill ncat"

	sync_set server test_end

	echo "----------------------------------------"
	echo "STEP 9: cleanup test"
	echo "----------------------------------------"
	swcfg_cleanup_bonding_by_linux_ifaces "$nic_list"

	ovs-vsctl del-port $ovs_br $tap2
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $if_bond

	for nic in $nic_list
	do
		ip link set $nic down
	done

	ip addr flush dev $ovs_br
	ip link set $nic_test up

	return $result
}

# Test chaining OVS bridges using veth
ovs_test_chained_with_veth()
{
	local mtu=${1:-1500}
	local result=0

	ip link add veth0 type veth peer name veth1
	ip link set veth0 up
	ip link set veth1 up

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev veth0
	ip link set mtu $mtu dev veth1

	ovs-vsctl add-port $ovs_br veth0
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl add-br ovsbr1
	ovs-vsctl add-port ovsbr1 veth1
	ovs-vsctl add-port ovsbr1 $nic_test

	ip link set mtu $mtu dev $tap1
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-vsctl show
	ip -d link show
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1

	ovs-vsctl del-port ovsbr1 $nic_test
	ovs-vsctl del-port ovsbr1 veth1
	ovs-vsctl del-br ovsbr1
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br veth0

	ip link set veth0 down
	ip link set veth1 down
	ip link del veth0

	ip link set mtu 1500 dev $nic_test

	return $result
}


# Test chaining OVS bridges using patch ports
ovs_test_chained_with_patchport()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl add-port $ovs_br patch1 -- set interface patch1 type=patch options:peer=patch2
	ovs-vsctl add-br ovsbr_patch
	ovs-vsctl add-port ovsbr_patch patch2 -- set interface patch2 type=patch options:peer=patch1
	ovs-vsctl add-port ovsbr_patch $nic_test
	ovs-vsctl show

	ip link set mtu $mtu dev $tap1
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1

	ovs-vsctl del-port ovsbr_patch $nic_test
	ovs-vsctl del-port ovsbr_patch patch2
	ovs-vsctl del-br ovsbr_patch
	ovs-vsctl del-port $ovs_br patch1
	ovs-vsctl del-port $ovs_br $tap1

	ip link set mtu 1500 dev $nic_test

	return $result
}

#
ovs_test_ns_ovsbr_nic()
{
	local mtu=${1:-1500}
	local result=0

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl show

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $ovs_br

	ip netns add ns1
	ip link set $ovs_br netns ns1
	ip netns exec ns1 ip link set $ovs_br up

	ip netns exec ns1 ip addr add $ipaddr_test/24 dev $ovs_br
	ip netns exec ns1 ip addr add $ip6addr_test/64 dev $ovs_br

	ip netns exec ns1 netserver

	ip -d link show

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME" $result_file
		do_ns_netperf ns1 $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	pkill -n netserver

	ip netns exec ns1 ip link set $ovs_br netns 1
	ip link set $ovs_br up
	ip netns del ns1

	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	ovs-vsctl del-port $ovs_br $nic_test

	return $result
}

ovs_test_ns1_ovsbr_ns2()
{
	local result=0

	if i_am_client; then
		ovs-vsctl add-port ovsbr0 ovs_p1 -- set interface ovs_p1 type=internal
		ovs-vsctl add-port ovsbr0 ovs_p2 -- set interface ovs_p2 type=internal
		ovs-vsctl show

		ip netns add ns1
		ip netns add ns2
		ip link set ovs_p1 netns ns1
		ip link set ovs_p2 netns ns2
		ip netns exec ns1 ip link set ovs_p1 up
		ip netns exec ns2 ip link set ovs_p2 up

		ip netns exec ns1 ip addr add $ipaddr_test/24 dev ovs_p1
		ip netns exec ns1 ip addr add $ip6addr_test/64 dev ovs_p1

		ip netns exec ns2 ip addr add $ipaddr_test_peer/24 dev ovs_p2
		ip netns exec ns2 ip addr add $ip6addr_test_peer/64 dev ovs_p2

		ip netns exec ns1 netserver
		ip netns exec ns2 netserver

		ip -d link show

		sync_wait server test_start

		log_header "$FUNCNAME" $result_file
		do_ns_netperf ns1 $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end

		pkill -n netserver

		ip netns exec ns1 ip link set ovs_p1 netns 1
		ip netns exec ns2 ip link set ovs_p2 netns 1
		ip netns del ns1
		ip netns del ns2

		ovs-vsctl del-port ovsbr0 ovs_p1
		ovs-vsctl del-port ovsbr0 ovs_p2
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	return $result
}

#
ovs_test_ns_veth_ovsbr_nic()
{
	local mtu=${1:-1500}
	local result=0

	ip link add veth0 type veth peer name veth1
	ip link set veth0 up
	ip link set veth1 up

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev veth0
	ip link set mtu $mtu dev veth1

	ovs-vsctl add-port $ovs_br veth1
	ovs-vsctl add-port $ovs_br $nic_test

	ip netns add ns1
	ip link set veth0 netns ns1
	ip netns exec ns1 ip link set veth0 up
	ip netns exec ns1 ip addr add $ipaddr_test/24 dev veth0
	ip netns exec ns1 ip addr add $ip6addr_test/64 dev veth0

	ip netns exec ns1 netserver

	ovs-vsctl show
	ip -d link show
	ip netns exec ns1 ip link show
	ip netns exec ns1 ip addr show

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME" $result_file
		do_ns_netperf ns1 $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	pkill -n netserver

	ip netns exec ns1 ip link set veth0 netns 1
	ip netns del ns1

	ovs-vsctl del-port $ovs_br veth1
	ovs-vsctl del-port $ovs_br $nic_test

	ip link set veth0 down
	ip link set veth1 down
	ip link del veth0

	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_mode_access()
{
	local mtu=${1:-1500}
	local result=0
	local vid=3

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl add-port $ovs_br $tap1 vlan_mode=access tag=$vid
	ovs-vsctl add-port $ovs_br $tap2
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file || { ((result += 1)); echo "FAIL: result=$result"; }

		vmsh run_cmd g1 "ping -c3 -w10 $ipaddr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g1 "ping6 -c3 -w10 $ip6addr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping -c3 -w10 $ipaddr_vm_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping6 -c3 -w10 $ip6addr_vm_peer" && { ((result += 1)); echo "FAIL: result=$result"; }

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tap2
	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_mode_trunk()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ip link set mtu $mtu dev $tap2
	ovs-vsctl add-port $ovs_br $nic_test -- set port $nic_test vlan_mode=trunk trunks=10,20
	ovs-vsctl add-port $ovs_br $tap1 tag=10
	ovs-vsctl add-port $ovs_br $tap2 tag=20
	ovs-vsctl show

	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g2 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:12 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu for vlan10" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file || { ((result += 1)); echo "FAIL: result=$result"; }

		log_header "$FUNCNAME $mtu for vlan20" $result_file
		do_vm_netperf g2 $ipaddr_vm2_peer $ip6addr_vm2_peer $result_file || { ((result += 1)); echo "FAIL: result=$result"; }

		vmsh run_cmd g1 "ping -c3 -w10 $ipaddr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g1 "ping6 -c3 -w10 $ip6addr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping -c3 -w10 $ipaddr_vm_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping6 -c3 -w10 $ip6addr_vm_peer" && { ((result += 1)); echo "FAIL: result=$result"; }

		ovs-vsctl remove port $nic_test trunks 20
		ovs-vsctl show

		vmsh run_cmd g1 "ping -c3 -w10 $ipaddr_vm_peer" || { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g1 "ping6 -c3 -w10 $ip6addr_vm_peer" || { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping -c3 -w10 $ipaddr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }
		vmsh run_cmd g2 "ping6 -c3 -w10 $ip6addr_vm2_peer" && { ((result += 1)); echo "FAIL: result=$result"; }

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tap2
	ovs-vsctl del-port $ovs_br $nic_test

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g2 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:12 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $tap2
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_mode_native_untagged()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	if i_am_client; then
		ip link set mtu $mtu dev $tap1
		ovs-vsctl add-port $ovs_br $nic_test tag=3 vlan_mode=native-untagged
		ovs-vsctl add-port $ovs_br $tap1 tag=3
		vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
		#make sure vm virtual port is up
		ip link set $tap1 up
		ip link set $tap2 up
		sync_wait server test_start
		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file ||((result += 1))
		sync_set server test_end

		sync_wait server test_start
		timeout 10 tcpdump -i $nic_test -e -c 10 icmp and host $ipaddr_vm > /tmp/native_untagged.asc
		grep "ICMP echo request" /tmp/native_untagged.asc| grep "vlan 3" && ((result+=1))
		grep "ICMP echo reply" /tmp/native_untagged.asc| grep "vlan 3" && ((result+=1))
		rm -f /tmp/native_untagged.asc
		ovs-vsctl del-port $ovs_br $tap1
		ovs-vsctl del-port $ovs_br $nic_test
		sync_set server test_end
	else
		ip link set mtu $mtu dev $tap1
		ip addr add $ipaddr_vm/24 dev $nic_test
		ip addr add $ip6addr_vm/64 dev $nic_test
		sync_set client test_start
		sync_wait client test_end

		ping $ipaddr_vm_peer &
		sync_set client test_start
		sync_wait client test_end
		ip addr flush $nic_test
		pkill -9 ping
	fi	
	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test
	return $result
}


ovs_test_vlan_mode_native_tagged()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	if i_am_client; then
		ip link set mtu $mtu dev $tap1
		ovs-vsctl add-port $ovs_br $nic_test tag=3 vlan_mode=native-tagged
		ovs-vsctl add-port $ovs_br $tap1 tag=3
		vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
		ip link set mtu $mtu dev $ovs_br
		ovs-vsctl show
		#make sure vm virtual port is up
		ip link set $tap1 up
		ip link set $tap2 up
		sync_wait server test_start
		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file ||((result += 1))
		sync_set server test_end

		sync_wait server test_start
		timeout 10 tcpdump -i $nic_test -e -c 10 icmp and host $ipaddr_vm > /tmp/native_tagged.asc
		grep "ICMP echo request" /tmp/native_tagged.asc| grep "vlan 3" || ((result+=1))
		grep "ICMP echo reply" /tmp/native_tagged.asc| grep "vlan 3" || ((result+=1))
		rm -f /tmp/native_tagged.asc
		sync_set server test_end
	else
		ip link set mtu $mtu dev $tap1
		ovs-vsctl add-port $ovs_br $nic_test tag=3 vlan_mode=native-tagged
		ovs-vsctl add-port $ovs_br $tap1 tag=3
		vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
		ip link set mtu $mtu dev $ovs_br
		ovs-vsctl show
		#make sure vm virtual port is up
		ip link set $tap1 up
		ip link set $tap2 up
		sync_set client test_start
		sync_wait client test_end

		vmsh run_cmd g1 "ping $ipaddr_vm_peer &"
		sync_set client test_start
		sync_wait client test_end
		vmsh run_cmd g1 "pkill -9 ping"
	fi
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test
	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	return $result
}

_ovs_test_vlan_mode_dot1q_tunnel()
{
	local mtu=${1:-1500}
	local result=0
	local vid=3

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ovs-vsctl add-port $ovs_br $nic_test vlan_mode=trunk trunks=$vid
	ovs-vsctl add-port $ovs_br $tap1 vlan_mode=dot1q-tunnel tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g1 "ip link add link \$(ip link show | grep -i ${mac4vm}:02 -B 1 | head -1 | awk -F':' '{print \$2}') name vlan10 type vlan id 10"
	vmsh run_cmd g1 "ip addr add $ipaddr_test/24 dev vlan10"
	vmsh run_cmd g1 "ip addr add $ip6addr_test/64 dev vlan10"
	vmsh run_cmd g1 "ip link set vlan10 up"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up
	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_test_peer $ipi6addr_test_peer $result_file || { ((result += 1)); echo "FAIL: result=$result"; }

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link del vlan10"
	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vlan_mode_dot1q_tunnel_cvlans()
{
	local mtu=${1:-1500}
	local result=0
	local vid=3

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1
	ovs-vsctl add-port $ovs_br $nic_test vlan_mode=trunk trunks=$vid
	ovs-vsctl add-port $ovs_br $tap1 vlan_mode=dot1q-tunnel tag=$vid cvlans=10
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	vmsh run_cmd g1 "ip link add link \$(ip link show | grep -i ${mac4vm}:02 -B 1 | head -1 | awk -F':' '{print \$2}') name vlan10 type vlan id 10"
	vmsh run_cmd g1 "ip addr add $ipaddr_test/24 dev vlan10"
	vmsh run_cmd g1 "ip addr add $ip6addr_test/64 dev vlan10"
	vmsh run_cmd g1 "ip link set vlan10 up"

	vmsh run_cmd g1 "ip link add link \$(ip link show | grep -i ${mac4vm}:02 -B 1 | head -1 | awk -F':' '{print \$2}') name vlan100 type vlan id 100"
	vmsh run_cmd g1 "ip addr add ${ipaddr_test}1/24 dev vlan100"
	vmsh run_cmd g1 "ip addr add ${ip6addr_test}1/64 dev vlan100"
	vmsh run_cmd g1 "ip link set vlan100 up"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up
	if i_am_client; then
		sync_wait server test_start
		ping ${ipaddr_test_peer}1 -c 3 && ((result += 1)) 
		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_test_peer $ipi6addr_test_peer $result_file || { ((result += 1)); echo "FAIL: result=$result"; }

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link del vlan10"
	vmsh run_cmd g1 "ip link del vlan100"
	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vlan_linux_vlan0()
{
	local mtu=${1:-1500}
	local vid=3
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link add link $nic_test name $nic_test.$vid type vlan id $vid
	ip link set $nic_test.$vid up
	ovs-vsctl add-port $ovs_br $nic_test.$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $nic_test.$vid
	ip link set $nic_test.$vid down
	ip link del $nic_test.$vid
	ip link set mtu 1500 dev $nic_test

	return $result
}

#Coverage of bug 1330655 
ovs_test_vlan_id0()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ovs-vsctl add-port $ovs_br $nic_test tag=0
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

#Coverage of bug 1330655 
ovs_test_vm_vlan_id0()
{
	local mtu=${1:-1500}
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $mtu dev $tap1

	ovs-vsctl add-port $ovs_br $nic_test
	ovs-vsctl add-port $ovs_br $tap1 tag=0
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $mtu dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group ff0e::$ipaddr local $ip6addr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-70)) dev $vxlan
	ip link set mtu $(($mtu-70)) dev $ovs_br
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan1_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ip6addr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-70)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vxlan_flow_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test

	ip link set mtu $(($mtu-70)) dev $ovs_br
	ip link show $ovs_br

	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=flow options:remote_ip=flow ofport_request=10
	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br "in_port=local actions=set_field:5->tun_id,set_field:$ip6addr_nic_peer->tun_ipv6_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_vxlan_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group ff0e::$ipaddr local $ip6addr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-70)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-70-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_vxlan1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	sleep 1
	ip link set vlan$vid up
	ip link set mtu $(($mtu-70-4)) dev vlan$vid
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group ff0e::$ipaddr local $ip6addr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-70)) dev $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan1_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vxlan_flow_ipv6()
{
	local mtu=${1:-1500}
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1
	ip addr add $ip6addr_nic/64 dev $nic_test

	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:key=flow options:remote_ip=flow ofport_request=10
	ovs-vsctl add-port $ovs_br $tap1
	ovs-ofctl del-flows  $ovs_br
	local of_port=$(ovs-ofctl dump-ports-desc $ovs_br | grep $tap1 | sed -r 's/^\s*(.*?)\(.*?\).*/\1/')
	ovs-ofctl add-flow  $ovs_br "in_port=$of_port actions=set_field:5->tun_id,set_field:$ip6addr_nic_peer->tun_ipv6_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_vxlan_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $vxlan type vxlan id $ipaddr group ff0e::$ipaddr local $ip6addr_nic dev $nic_test
	ip link set $vxlan up
	sleep 1
	ip link set mtu $(($mtu-70-4)) $vxlan
	ovs-vsctl add-port $ovs_br $vxlan
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $vxlan
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip link set $vxlan down
	ip link del $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_vxlan1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local vxlan=vxlan0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $vxlan -- set interface $vxlan type=vxlan options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $vxlan
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}


ovs_test_geneve_ipv6()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ip6addr_nic_peer
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	sleep 1
	ip link set mtu $(($mtu-70)) dev $ovs_br
	ip link set mtu $(($mtu-70)) dev $tun
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $tun
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_geneve1_ipv6()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ip6addr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-70)) dev $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_geneve_flow_ipv6()
{
	local mtu=${1:-1500}
	local geneve=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test

	ip link set mtu $(($mtu-70)) dev $ovs_br
	ip link show $ovs_br

	ovs-vsctl add-port $ovs_br $geneve -- set interface $geneve type=geneve options:key=flow options:remote_ip=flow ofport_request=10
	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br "in_port=local actions=set_field:5->tun_id,set_field:$ip6addr_nic_peer->tun_ipv6_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $geneve
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_geneve_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ip6addr_nic_peer
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-70-4)) dev vlan$vid
	ip link set mtu $(($mtu-70-4)) dev $tun
	ovs-vsctl show

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $tun
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vlan_geneve1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-70-4)) dev vlan$vid

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_gre_ipv6()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $gre type ip6gretap remote $ip6addr_nic_peer local $ip6addr_nic
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl show
	sleep 1
	ip link set mtu $(($mtu-40-4-14)) dev $ovs_br
	ip link set mtu $(($mtu-40-4-14)) dev $gre

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_gre1_ipv6()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl show
	ip link set mtu $(($mtu-40-4-14)) dev $ovs_br

	ip addr add $ipaddr_test/24 dev $ovs_br
	ip addr add $ip6addr_test/64 dev $ovs_br

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show $ovs_br

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev $ovs_br

	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ip6ddr_nic/64 dev $nic_test
	ip link set mtu 1500 $ovs_br
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vlan_gre_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $gre type ip6gretap remote $ip6addr_nic_peer local $ip6addr_nic
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-40-4-14-4)) dev vlan$vid
	ip link set mtu $(($mtu-40-4-14-4)) dev $gre

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ip link set vlan$vid down
	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vlan_gre1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br vlan$vid tag=$vid -- set interface vlan$vid type=internal
	ovs-vsctl show
	ip link set vlan$vid up
	sleep 1
	ip link set mtu $(($mtu-40-4-14-4)) dev vlan$vid

	ip addr add $ipaddr_test/24 dev vlan$vid
	ip addr add $ip6addr_test/64 dev vlan$vid

	ip -d link show $nic_test
	ip -d link show $ovs_br
	ip addr show $nic_test
	ip addr show vlan$vid

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_host_netperf $ipaddr_test_peer $ip6addr_test_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	ip addr flush dev vlan$vid

	ovs-vsctl del-port $ovs_br vlan$vid
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ip6addr_nic/64 dev $nic_test
	ip link set mtu 1500 dev $nic_test

	return $result
}


ovs_test_vm_geneve_ipv6()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ip6addr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-70)) dev $tun
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $tun
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_geneve1_ipv6()
{
	local mtu=${1:-1500}
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_geneve_flow_ipv6()
{
	local mtu=${1:-1500}
	local geneve=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70)) dev $tap1
	ip addr add $ip6addr_nic/64 dev $nic_test

	ovs-vsctl add-port $ovs_br $geneve -- set interface $geneve type=geneve options:key=flow options:remote_ip=flow ofport_request=10
	ovs-vsctl add-port $ovs_br $tap1
	ovs-ofctl del-flows  $ovs_br
	local of_port=$(ovs-ofctl dump-ports-desc $ovs_br | grep $tap1 | sed -r 's/^\s*(.*?)\(.*?\).*/\1/')
	ovs-ofctl add-flow  $ovs_br "in_port=$of_port actions=set_field:5->tun_id,set_field:$ip6addr_nic_peer->tun_ipv6_dst,output:10"
	ovs-ofctl add-flow  $ovs_br actions=NORMAL
	ovs-ofctl dump-flows  $ovs_br
	ovs-vsctl show

	vmsh run_cmd g1 "ip link set mtu $(($mtu-70)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi


	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-ofctl del-flows  $ovs_br
	ovs-ofctl add-flow  $ovs_br actions=NORMAL

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $geneve
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_geneve_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $tun type geneve id $ipaddr remote $ip6addr_nic_peer
	sleep 1
	ip link set mtu $(($mtu-70-4)) dev $tun
	ip link set $tun up
	ovs-vsctl add-port $ovs_br $tun
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip link set $tun down
	ip link del $tun
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

ovs_test_vm_vlan_geneve1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local tun=geneve0
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-70-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $tun -- set interface $tun type=geneve options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-70-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $tun
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vm_gre_ipv6()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-40-4-14)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $gre type gretap remote $ip6addr_nic_peer local $ip6addr_nic
	sleep 1
	ip link set mtu $(($mtu-40-4-14)) dev $gre
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-40-4-14)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vm_gre1_ipv6()
{
	local mtu=${1:-1500}
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-40-4-14)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-40-4-14)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vm_vlan_gre_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-40-4-14-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ip link add $gre type gretap remote $ip6addr_nic_peer local $ip6addr_nic
	sleep 1
	ip link set mtu $(($mtu-40-4-14-4)) dev $gre
	ip link set $gre up
	ovs-vsctl add-port $ovs_br $gre
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-40-4-14-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $gre
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip link set $gre down
	ip link del $gre
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

_ovs_test_vm_vlan_gre1_ipv6()
{
	local mtu=${1:-1500}
	local vid=3
	local gre=gre1
	local result=0

	ip link set mtu $mtu dev $nic_test
	for ((i=0; i<30; i++))
	do
		ip link show $nic_test | grep 'NO-CARRIER' >/dev/null || break
		sleep 1
	done

	ip link set mtu $(($mtu-40-4-14-4)) dev $tap1

	ip addr add $ip6addr_nic/64 dev $nic_test
	ovs-vsctl add-port $ovs_br $gre -- set interface $gre type=gre options:remote_ip=$ip6addr_nic_peer
	ovs-vsctl add-port $ovs_br $tap1 tag=$vid
	ovs-vsctl show
	vmsh run_cmd g1 "ip link set mtu $(($mtu-40-4-14-4)) dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"

	ip -d link show $nic_test
	ip -d link show $tap1
	ip -d link show $ovs_br
	ip addr show $nic_test
	vmsh run_cmd g1 "ip -d link show; ip addr show"
	#make sure vm virtual port is up
	ip link set $tap1 up
	ip link set $tap2 up

	if i_am_client; then
		sync_wait server test_start

		log_header "$FUNCNAME $mtu" $result_file
		do_vm_netperf g1 $ipaddr_vm_peer $ip6addr_vm_peer $result_file
		result=$?

		sync_set server test_end
	else
		sync_set client test_start
		sync_wait client test_end
	fi

	vmsh run_cmd g1 "ip link set mtu 1500 dev \$(ip link show|grep -i ${mac4vm}:02 -B 1|awk '/^[0-9]+/ {gsub(\":\",\"\",\$2); print \$2}')"
	ovs-vsctl del-port $ovs_br $tap1
	ovs-vsctl del-port $ovs_br $gre
	ip addr del $ip6addr_nic/64 dev $nic_test

	ip link set mtu 1500 dev $tap1
	ip link set mtu 1500 dev $nic_test

	return $result
}

# main

rlJournalStart

rlPhaseStartSetup

if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	rlRun "cleanup_env"
fi

rlRun "get_address"

if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	if i_am_client; then
		echo "OVS_TEST_RESULT($nic_driver/$nic_test):	$(date)" > $result_file
		echo "kernel: $(uname -r)" >> $result_file
		echo "CLIENTS: $CLIENTS" >> $result_file
		echo "SERVERS: $SERVERS" >> $result_file
		echo ""
	fi
	rlRun "setup_env"
fi

tap1=$(ip link show|grep -i $(expr substr ${mac_g1} 4 ${#mac_g1}) -B 1|awk '/^[0-9]+/ {gsub(":","",$2); print $2}')
tap2=$(ip link show|grep -i $(expr substr ${mac_g2} 4 ${#mac_g2}) -B 1|awk '/^[0-9]+/ {gsub(":","",$2); print $2}')
echo "tap1=$tap1"
echo "tap2=$tap2"

ovs-vsctl --if-exists del-port ovsbr0 $tap1
ovs-vsctl --if-exists del-port ovsbr0 $tap2
sleep 2
ip link set $tap1 up
ip link set $tap2 up


rlPhaseEnd

if [ "$OVS_TOPO" = "setup" ]; then
	rlJournalPrintText
	rlJournalEnd
	exit 0
fi

my_run_test "ovs_test_nic"
my_run_test "ovs_test_vlan"
my_run_test "ovs_test_vlan1"
my_run_test "ovs_test_vxlan_mtu_check" "jumbo_test=no"
my_run_test "ovs_test_vxlan"
my_run_test "ovs_test_vxlan1"
my_run_test "ovs_test_vxlan_flow"
my_run_test "ovs_test_vlan_vxlan"
my_run_test "ovs_test_vlan_vxlan1"
my_run_test "ovs_test_geneve" "ovs_version>=2.4"
my_run_test "ovs_test_geneve1" "ovs_version>=2.4"
my_run_test "ovs_test_vlan_geneve" "ovs_version>=2.4"
my_run_test "ovs_test_vlan_geneve1" "ovs_version>=2.4"
my_run_test "ovs_test_gre"
my_run_test "ovs_test_gre1"
my_run_test "ovs_test_vlan_gre"
my_run_test "ovs_test_vlan_gre1"
my_run_test "ovs_test_vm_nic"
my_run_test "ovs_test_vm_vlan"
my_run_test "ovs_test_vm_multiple_vlans"
my_run_test "ovs_test_vm_vxlan"
my_run_test "ovs_test_vm_vxlan1"
my_run_test "ovs_test_vm_vxlan_flow"
my_run_test "ovs_test_vm_vxlan_gbp" "ovs_version>=2.4"
my_run_test "ovs_test_vm_vlan_vxlan"
my_run_test "ovs_test_vm_vlan_vxlan1"
my_run_test "ovs_test_vm_geneve" "ovs_version>=2.4"
my_run_test "ovs_test_vm_geneve1" "ovs_version>=2.4"
my_run_test "ovs_test_vm_vlan_geneve" "ovs_version>=2.4"
my_run_test "ovs_test_vm_vlan_geneve1" "ovs_version>=2.4"
my_run_test "ovs_test_vm_gre"
my_run_test "ovs_test_vm_gre1"
my_run_test "ovs_test_vm_vlan_gre"
my_run_test "ovs_test_vm_vlan_gre1"
my_run_test "ovs_test_bond_active_backup" "jumbo_test=no"
my_run_test "ovs_test_bond_set_active_slave" "jumbo_test=no"
my_run_test "ovs_test_bond_lacp_active" "jumbo_test=no"
my_run_test "ovs_test_bond_lacp_passive" "jumbo_test=no"
my_run_test "ovs_test_bond_balance_slb" "jumbo_test=no"
my_run_test "ovs_test_bond_balance_tcp" "jumbo_test=no"
my_run_test "ovs_test_chained_with_veth"
my_run_test "ovs_test_chained_with_patchport"
my_run_test "ovs_test_ns_ovsbr_nic"
my_run_test "ovs_test_ns1_ovsbr_ns2" "jumbo_test=no"
my_run_test "ovs_test_ns_veth_ovsbr_nic"
my_run_test "ovs_test_vlan_mode_access"
my_run_test "ovs_test_vlan_mode_trunk"
my_run_test "ovs_test_vlan_mode_native_untagged"
my_run_test "ovs_test_vlan_mode_native_tagged"
my_run_test "ovs_test_vlan_id0"
my_run_test "ovs_test_vm_vlan_id0"
my_run_test "ovs_test_vxlan_ipv6"
my_run_test "ovs_test_vxlan1_ipv6"
my_run_test "ovs_test_vxlan_flow_ipv6"
my_run_test "ovs_test_vlan_vxlan_ipv6"
my_run_test "ovs_test_vlan_vxlan1_ipv6"
my_run_test "ovs_test_vm_vxlan_ipv6"
my_run_test "ovs_test_vm_vxlan1_ipv6"
my_run_test "ovs_test_vm_vxlan_flow_ipv6"
my_run_test "ovs_test_vm_vlan_vxlan_ipv6"
my_run_test "ovs_test_vm_vlan_vxlan1_ipv6"
my_run_test "ovs_test_geneve_ipv6"
my_run_test "ovs_test_geneve1_ipv6"
my_run_test "ovs_test_vlan_geneve_ipv6"
my_run_test "ovs_test_vlan_geneve1_ipv6"
my_run_test "_ovs_test_gre_ipv6"
my_run_test "_ovs_test_gre1_ipv6"
my_run_test "_ovs_test_vlan_gre_ipv6"
my_run_test "_ovs_test_vlan_gre1_ipv6"
my_run_test "ovs_test_vm_geneve_ipv6"
my_run_test "ovs_test_vm_geneve1_ipv6"
my_run_test "ovs_test_vm_vlan_geneve_ipv6"
my_run_test "ovs_test_vm_vlan_geneve1_ipv6"
my_run_test "_ovs_test_vm_gre_ipv6"
my_run_test "_ovs_test_vm_gre1_ipv6"
my_run_test "_ovs_test_vm_vlan_gre_ipv6"
my_run_test "_ovs_test_vm_vlan_gre1_ipv6"


if [ "$OVS_SKIP_SETUP_ENV" != "yes" ]; then
	rlPhaseStartCleanup

	cleanup_env
	echo 1 > /proc/sys/net/ipv6/conf/$nic_test/accept_ra

	rlPhaseEnd
fi

if i_am_client; then
	rhts_submit_log -l $result_file
fi

rlJournalPrintText
rlJournalEnd
