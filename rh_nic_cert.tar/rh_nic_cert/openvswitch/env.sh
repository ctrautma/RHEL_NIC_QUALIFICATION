#!/bin/bash - 

########################################################
# CONFIGURATIONS
########################################################

set -o nounset

OVS_TOPO=${QE_TEST:-ovs_all}
OVS_SKIP_SETUP_ENV=${QE_SKIP_SETUP_ENV:-no}
OVS_SKIP=${QE_SKIP_TEST:-""}

SETENFORCE=${SETENFORCE:-'Permissive'}

set +o nounset

echo "========================================="
echo "TEST CONFIGURATIONS"
echo "========================================="
cat /etc/redhat-release
echo "CLIENTS=$CLIENTS"
echo "SERVERS=$SERVERS"
echo
echo "RPM_OVS=$RPM_OVS"
echo "IMG_GUEST=$IMG_GUEST"
echo "SRC_NETPERF=$SRC_NETPERF"
echo "RPM_KERNEL=$RPM_KERNEL"
echo
echo "OVS_TOPO=$OVS_TOPO"
echo "OVS_SKIP_SETUP_ENV=$OVS_SKIP_SETUP_ENV"
echo "OVS_SKIP=$OVS_SKIP"
echo "========================================="

rhel_version=$(cut -f1 -d. /etc/redhat-release | sed 's/[^0-9]//g')

########################################################
# Install needed packages
########################################################

do_install()
{
	rpm_install() {
		[ "$(rpm -q $(basename -s .rpm $1))" != "$(basename -s .rpm $1)" ] && rpm -Uvh --force --nodeps $1
	}
	
	wget -V 2>/dev/null || yum -y install wget
	git --version 2>/dev/null || yum -y install git
	gcc --version || yum -y install gcc
	
	brctl -V 2>/dev/null || yum -y install bridge-utils
	virt-install --version 2>/dev/null || yum -y install virt-install
	libvirtd -V  2>/dev/null || yum -y install libvirt
	rpm -q qemu-kvm 2>/dev/null || rpm -q qemu-kvm-rhev 2>/dev/null || yum -y install qemu-kvm
	
	yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
	bc --version 2>/dev/null || yum -y install bc
	lsof -v 2 || yum -y install lsof
	ncat --version 2>/dev/null || yum -y install nmap-ncat
	expect -v 2>/dev/null || yum -y install expect
	tcpdump --version 2>/dev/null || yum -y install tcpdump
	#rpm_install $IPERF_RPM
	iperf -v 2>/dev/null || yum -y install iperf
	sshpass -V 2>/dev/null || yum -y install sshpass
	
	if which beakerlib-journalling 2>/dev/null
	then
		local BEAKERLIB_ROOT=$(which beakerlib-journalling | sed 's/\/usr\/bin\/beakerlib-journalling//')
	else
		git clone https://github.com/beakerlib/beakerlib
		pushd beakerlib
		make
		make install DD=${RH_NIC_CERT_ROOT}/lib/beakerlib
		export PATH="${PATH}:${RH_NIC_CERT_ROOT}/lib/beakerlib/usr/bin"
		local BEAKERLIB_ROOT="${RH_NIC_CERT_ROOT}/lib/beakerlib"
		popd
		export BEAKERLIB=${BEAKERLIB_ROOT}/usr/share/beakerlib/
	fi
	source ${BEAKERLIB_ROOT}/usr/share/beakerlib/beakerlib.sh
	
	if ! netperf -V 2>/dev/null; then
		wget -nv -N $SRC_NETPERF
		tar xjvf $(basename $SRC_NETPERF)
		netperf_dir=$(basename $SRC_NETPERF)
		pushd ${netperf_dir/\.*/}
		./configure && make && make install
		popd 1>/dev/null
		rm -rf netperf-*
	fi
	pkill netserver; sleep 2; netserver
	
	if (($rhel_version < 7)); then
		service libvirtd restart
	else
		systemctl restart libvirtd
		#systemctl restart virtlogd.socket
	fi
	# workaround for failure of virt-install
	chmod 666 /dev/kvm
	
	rpm_install $RPM_OVS

	# download guest image
	pushd "/var/lib/libvirt/images/" 1>/dev/null
	if ! [[ -f $(basename -s .lrz $IMG_GUEST) ]]
	then
		[[ -f $(basename $IMG_GUEST) ]] || wget -nv -N $IMG_GUEST
		if [[ "${IMG_GUEST##*.}" = "lrz" ]]
		then
			rpm -q epel-release-7 || yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
			lrzip -V 2>/dev/null || yum -y install lrzip
			lrzip -d "$(basename $IMG_GUEST)"
		fi
	fi
	popd 1>/dev/null
}

[[ "$OVS_SKIP_SETUP_ENV" != "yes" ]] && do_install

########################################################
# Set up initial variables used in test
########################################################

export PATH="${PATH}:${RH_NIC_CERT_ROOT}/bin/"

source ${RH_NIC_CERT_ROOT}/lib/lib_utils.sh || exit 1
source ${RH_NIC_CERT_ROOT}/lib/lib_swcfg.sh || exit 1
source ${RH_NIC_CERT_ROOT}/lib/lib_nc_sync.sh || exit 1
source ${RH_NIC_CERT_ROOT}/lib/lib_netperf_all.sh || exit 1

if i_am_client
then
	NIC_TEST=$NIC_CLIENT
	SW_NAME=$SW_NAME
	SW_PORT=$SW_PORT_CLIENT
else
	NIC_TEST=$NIC_SERVER
	SW_NAME=$SW_NAME
	SW_PORT=$SW_PORT_SERVER
fi

swcfg setup "$SW_NAME" "$SW_PORT"

# clear the dirty configuration if any
virsh list --all 2>/dev/null | sed -n 3~1p | awk '/[[:alpha:]]+/ {
    if ($3 == "running") {
        system("virsh destroy "$2" &>/dev/null")
        sleep 2;
    };
    system("virsh undefine --managed-save --snapshots-metadata --remove-all-storage "$2" &>/dev/null")
}'

ovs-vsctl --if-exists del-br ovsbr0 &>/dev/null
systemctl stop openvswitch &>/dev/null
sleep 5
dpdk-devbind -s 2>/dev/null | grep drv=vfio-pci | awk '{system("driverctl -v unset-override "$1)}' &>/dev/null
sleep 5

# get the required info
nic_test=$(NIC_NUM=1 get_required_iface)
echo "nic_test: $nic_test"
nic_driver=$(ethtool -i $nic_test | grep driver | awk '{print $2}')
nic_driver=$(ethtool -i $nic_test | grep driver | awk '{print $2}')
result_file=${result_file:-"ovs_$nic_driver.log"}

echo "========================================="
echo " Hardware information"
echo "========================================="
ethtool -i $nic_test
echo
lspci -vvv -s $(ethtool -i $nic_test | sed -n 's/bus-info: \(.*\)/\1/p')
echo "========================================="

ovs_br=${ovs_br:-ovsbr0}

setenforce $SETENFORCE

########################################################
# Set up IP addresses used in test
########################################################

get_address()
{
	if [ -z "$JOBID" ]; then
		ipaddr=120
	else
		ipaddr=$((JOBID % 100 + 20))
	fi

	if i_am_client; then
		mac4vm="00:de:ad:$(printf "%02x" $ipaddr):01"

		ipaddr_nic=172.31.$((ipaddr + 0)).1
		ipaddr_nic_peer=172.31.$((ipaddr + 0)).2
		ip6addr_nic=2001:0db8:$((ipaddr + 0))::1
		ip6addr_nic_peer=2001:0db8:$((ipaddr + 0))::2

		ipaddr_test=172.31.$((ipaddr + 50)).1
		ipaddr_test_peer=172.31.$((ipaddr + 50)).2
		ipaddr_test_vlan=172.31.$((ipaddr + 50)).5
		ipaddr_test_vlan_peer=172.31.$((ipaddr + 50)).6
		ip6addr_test=2001:0db8:$((ipaddr + 50))::1
		ip6addr_test_peer=2001:0db8:$((ipaddr + 50))::2

		ipaddr_vm=172.31.$((ipaddr + 100)).1
		ipaddr_vm_peer=172.31.$((ipaddr + 100)).2
		ip6addr_vm=2001:0db8:$((ipaddr + 100))::1
		ip6addr_vm_peer=2001:0db8:$((ipaddr + 100))::2

		ipaddr_test_veth1=172.31.$((ipaddr + 50)).3
		ipaddr_test_veth2=172.31.$((ipaddr + 50)).4

		ipaddr_vm2=172.31.$((ipaddr + 100)).11
		ipaddr_vm2_peer=172.31.$((ipaddr + 100)).12
		ip6addr_vm2=2001:0db8:$((ipaddr + 100))::11
		ip6addr_vm2_peer=2001:0db8:$((ipaddr + 100))::12
	else
		mac4vm="00:de:ad:$(printf "%02x" $ipaddr):02"

		ipaddr_nic=172.31.$((ipaddr + 0)).2
		ipaddr_nic_peer=172.31.$((ipaddr + 0)).1
		ip6addr_nic=2001:0db8:$((ipaddr + 0))::2
		ip6addr_nic_peer=2001:0db8:$((ipaddr + 0))::1

		ipaddr_test=172.31.$((ipaddr + 50)).2
		ipaddr_test_peer=172.31.$((ipaddr + 50)).1
		ipaddr_test_vlan=172.31.$((ipaddr + 50)).6
		ipaddr_test_vlan_peer=172.31.$((ipaddr + 50)).5
		ip6addr_test=2001:0db8:$((ipaddr + 50))::2
		ip6addr_test_peer=2001:0db8:$((ipaddr + 50))::1

		ipaddr_vm=172.31.$((ipaddr + 100)).2
		ipaddr_vm_peer=172.31.$((ipaddr + 100)).1
		ip6addr_vm=2001:0db8:$((ipaddr + 100))::2
		ip6addr_vm_peer=2001:0db8:$((ipaddr + 100))::1

		ipaddr_vm2=172.31.$((ipaddr + 100)).12
		ipaddr_vm2_peer=172.31.$((ipaddr + 100)).11
		ip6addr_vm2=2001:0db8:$((ipaddr + 100))::12
		ip6addr_vm2_peer=2001:0db8:$((ipaddr + 100))::11
	fi

	mac_g1=${mac4vm}:02
	mac_g2=${mac4vm}:12
}


